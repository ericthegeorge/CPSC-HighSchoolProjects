"use strict";
// Programmer's Name:
// Program Name:
//////////////////////////////////////////////////////////////////////////

load("cs10-txt-lib-0.4.js");
// Don't edit the line above, or you won't be able to get user input!

// Also, do not use the following variable names in your own code below:
//    load, print, getInput, javaSleep, currentDate, getWorkingDirectory, newFileReader, fileHasInput, fileGetInput, newFileWriter, newFileAppender, filePrint, fileClose

// Write your program below this line:
// ***********************************
var number1;
var number2;
var number3;
var number4;
var number5;
var number6;
var number7;
var number8;
var number9;
var number0;




print("This program will find the mean average of 10 numbers.");
print("Please enter a number:");
number1 = parseInt(getInput());
print("Please enter a number:");
number2 = parseInt(getInput());
print("Please enter a number:");
number3 = parseInt(getInput());
print("Please enter a number:");
number4 = parseInt(getInput());
print("Please enter a number:");
number5 = parseInt(getInput());
print("Please enter a number:");
number6 = parseInt(getInput());
print("Please enter a number:");
number7 = parseInt(getInput());
print("Please enter a number:");
number8 = parseInt(getInput());
print("Please enter a number:");
number9 = parseInt(getInput());
print("Please enter a number:");
number0 = parseInt(getInput());
print("The mean average is:", (number1 + number2 + number3 + number4 + number5 + number6 + number7 + number8 + number9 + number0) / 10);

