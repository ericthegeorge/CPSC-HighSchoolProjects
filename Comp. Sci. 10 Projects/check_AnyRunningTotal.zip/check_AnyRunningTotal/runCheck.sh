#!/bin/sh
deno --allow-run --allow-read --allow-write="out.txt" "http://www.chenglearningmachine.ca/cs/ts_libs/check_myprogram_js.ts" <in.txt
$SHELL

