/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exceptionsprojects;

import java.util.Scanner;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here\
        System.out.println("Print exit to escape\n");
        String input = "~";
        boolean b = true;
        while (b && !input.equalsIgnoreCase("exit")) {
            try {
                Scanner sc = new Scanner(System.in);
                input = sc.nextLine();
                FileInput.readTheFile(input);
                System.out.println("It worked.");
                b = false;
            } catch (Exception IOException) {

            }
        }
        if (input.equalsIgnoreCase("exit")){
        System.out.println("It did not work.");
        }
    }

}
