/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exceptionsprojects;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author 1100015542
 */
public class FileInput {
    public static void readTheFile(String fileName) throws IOException {
        Scanner fs = new Scanner(new File(fileName));
        int maxIndx = -1;
        String[] text = new String[1000];
        while (fs.hasNext()) {
            ++maxIndx;
            text[maxIndx] = fs.nextLine();
        }
        fs.close();
        for (int i = 0; i <= maxIndx; ++i) {
            System.out.println(text[i]);
        }
    }
}
