/**
 * This is a class that tests the Card class.
 */
public class CardTester {

	/**
	 * The main method in this class checks the Card operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		/* *** TO BE IMPLEMENTED IN ACTIVITY 1 *** */
                Card aceSpade = new Card("ace", "spades", 1);
                Card aceSpade2 = new Card("ace", "spades", 1);  
                Card kingDice = new Card("king", "diamonds", 12);
                System.out.println(aceSpade.matches(aceSpade2));
                System.out.println(kingDice.rank() + kingDice.suit() + kingDice.pointValue());
                System.out.println(kingDice.toString());
	}
}
