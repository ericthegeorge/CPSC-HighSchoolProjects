package gp5novelhistogram;

import java.util.Scanner;

public class CryptoAnalysis {

    public static CharFrequency[] charFrequenciesOf(String theTextStr) {
        CharFrequency[] charFreqs = new CharFrequency[10 + 26 + 26]; // 0 to 9, a to z, A to Z
        //nums
        for (int i = 0; i < 10; i++){
            charFreqs[i] = new CharFrequency((char) (i + 48));
        }
        //low letter
        for (int i = 0; i < 26; i++){
            charFreqs[i + 10] = new CharFrequency((char) (i + 97));
        }
        //up letter
                for (int i = 0; i < 26; i++){
            charFreqs[i + 10 + 26] = new CharFrequency((char) (65 + i));
        }
        
        for (int i = 0; i < theTextStr.length(); i ++){
            char current = theTextStr.charAt(i);
            
            for (int j = 0; j < charFreqs.length; j++){
                CharFrequency currentCharFreq = charFreqs[j];
                if (currentCharFreq.getChar() == current) {
                    currentCharFreq.plusOne();
                }
            }
        }
        
        
        
        
        
        
        
        //long start = System.nanoTime();
//        for (int i = 0; i <= 9; i++) {
//            CharFrequency aNum = new CharFrequency((char) (i + 48));
//            Scanner sc = new Scanner(theTextStr);
//            char ch = '0';
//            while (sc.hasNext()) {
//                String word = sc.next();
//                for (int j = 0; j < word.length(); j++) {
//                    ch = word.charAt(j);
//                    if (ch == (char) (i + 48)) {
//                        aNum.plusOne();
//                    }
//                }
//            }
//
//            charFreqs[i] = aNum;
//        }
//
//        for (int i = 0; i <= 25; i++) {
//            CharFrequency lowLetter = new CharFrequency((char) (97 + i));
//            Scanner sc = new Scanner(theTextStr);
//                        char ch = '0';
//            while (sc.hasNext()) {
//                String word = sc.next();
//                for (int j = 0; j < word.length(); j++) {
//                    ch = word.charAt(j);
//                    if (ch == (char) (i + 97)) {
//                        lowLetter.plusOne();
//                    }
//                }
//            }
//            charFreqs[i + 10] = lowLetter;
//        }
//
//        for (int i = 0; i <= 25; i++) {
//            CharFrequency upLetter = new CharFrequency((char) (65 + i));
//            Scanner sc = new Scanner(theTextStr);
//                        char ch = '0';
//            while (sc.hasNext()) {
//                String word = sc.next();
//                for (int j = 0; j < word.length(); j++) {
//                    ch = word.charAt(j);
//                    if (ch == (char) (i + 65)) {
//                        upLetter.plusOne();
//                    }
//                }
//            }
//            charFreqs[i + 36] = upLetter;
//        }
       // long end = System.nanoTime() - start;
        //System.out.println((double)end / (1000.0 * 1000.0));
        return charFreqs;
    }
}


