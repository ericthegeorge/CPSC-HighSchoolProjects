
package backend_models;

/**
 *
 * @author erick
 */
public class HandTrendAnalyzer {
    NLinkedList handLocs;
    public static void updateHandLocList(){
        
    }
    public static int[] determineTrend(int[] handLoc){
        return null;
    }
}
