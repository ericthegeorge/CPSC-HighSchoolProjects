/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend_models;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.event.InputEvent;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author erick
 */
public class RobotCursor extends Robot {

    private Robot r;
    private Point p = MouseInfo.getPointerInfo().getLocation();
    private Thread t;

    private boolean scrollWheelButtonPressed;

    public boolean isScrollWheelButtonPressed() {
        return scrollWheelButtonPressed;
    } 
    
    private boolean leftButtonPressed;
    private boolean rightButtonPressed;

    public Thread getT() {
        return t;
    }

    public void setT(Thread t) {
        this.t = t;
    }

    public RobotCursor() throws AWTException {
        this.rightButtonPressed = false;
        this.leftButtonPressed = false;
        this.scrollWheelButtonPressed = false;
        r = new Robot();
    }

    /*
    potentially automate determination of how long and steps by using a constant factor 
     */
    public void glide(int x, int y, int milliTime, int steps) {
        /*
        due to rounding we may not always get to the exact location but it should be fine considering hand 
        movement translation is already inaccurate
        after making that more precise focus here
         */
        this.p = MouseInfo.getPointerInfo().getLocation();
        int x2 = x;
        int y2 = y;
        double deltaX = (x2 - p.x) / (double) steps;
        double deltaY = (y2 - p.y) / (double) steps;
        double deltaT = (double) milliTime / (double) steps;
        t = new Thread(() -> {
            for (int i = 0; i < steps; ++i) {
                try {
                    Thread.sleep((int) deltaT);
                    this.r.mouseMove((int) (p.x + deltaX * i), (int) (p.y + deltaY * i));
                } catch (InterruptedException ex) {
                    Logger.getLogger(RobotCursor.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        t.start();
    }

    public void glide(int[] coords, int milliTime, int steps) {
        this.p = MouseInfo.getPointerInfo().getLocation();
        int x = coords[0];
        int y = coords[1];
        this.glide(x, y, milliTime, steps);
    }

    public void glide(int[] coords) {
        this.p = MouseInfo.getPointerInfo().getLocation();
        int x = coords[0];
        int y = coords[1];
        double dist = Math.sqrt(x * x + y * y);
        int milliTime = (int) dist;
        int steps = milliTime / 12;
        this.glide(x, y, milliTime, steps);
    }

    public void glide(int x, int y) {
        this.p = MouseInfo.getPointerInfo().getLocation();
        double dist = Math.sqrt(x * x + y * y);
        int milliTime = (int) dist;
        int steps = milliTime / 12;
        this.glide(x, y, milliTime, steps);
    }

    /*
InputEvent.BUTTON1_DOWN_MASK :  For mouse left -click

InputEvent.BUTTON2_DOWN_MASK  : For mouse middle button click.

InputEvent.BUTTON3_DOWN_MASK : For mouse right-click

InputEvent.BUTTON1_MASK

InputEvent.BUTTON2_MASK

InputEvent.BUTTON3_MASK


     */
    /**
     *
     * @param i where 1 is left, 2 is right, and anything else (3) is mouse
     * button
     */
    public void leftClick() {
        if (this.leftButtonPressed) {
            this.leftButtonPressed = false;
            this.r.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        } else {
            this.leftButtonPressed = true;
            this.r.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        }
    }

    public void rightClick() {
        if (this.rightButtonPressed) {
            this.rightButtonPressed = false;
            this.r.mouseRelease(InputEvent.BUTTON3_DOWN_MASK);
        } else {
            this.rightButtonPressed = true;
            this.r.mousePress(InputEvent.BUTTON3_DOWN_MASK);
        }
    }

    public void scrollClick() {
        if (this.scrollWheelButtonPressed) {
            this.r.mouseRelease(InputEvent.BUTTON2_DOWN_MASK);
            this.scrollWheelButtonPressed = false;
        } else {
            this.r.mousePress(InputEvent.BUTTON2_DOWN_MASK);
            this.scrollWheelButtonPressed = true;
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    
    
        public void leftClickPress() {
            this.leftButtonPressed = true;
            this.r.mousePress(InputEvent.BUTTON1_DOWN_MASK);
    }

    public void rightClickPress() {
              this.rightButtonPressed = true;
            this.r.mousePress(InputEvent.BUTTON3_DOWN_MASK);
    }

    public void scrollClickPress() {
                 this.scrollWheelButtonPressed = true;
            this.r.mousePress(InputEvent.BUTTON2_DOWN_MASK);
    }    
    public void leftClickRelease() {
            this.leftButtonPressed = false;
            this.r.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        
    }
    public void rightClickRelease() {
            this.rightButtonPressed = false;
            this.r.mouseRelease(InputEvent.BUTTON3_DOWN_MASK);
        
    }
    public void scrollClickRelease() {
            this.scrollWheelButtonPressed = false;
            this.r.mouseRelease(InputEvent.BUTTON2_DOWN_MASK);
        
    }

    
    
}
