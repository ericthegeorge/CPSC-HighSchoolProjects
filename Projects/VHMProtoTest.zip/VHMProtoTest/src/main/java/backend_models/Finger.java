/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package backend_models;

import org.opencv.core.Point;

/**
 *
 * @author 1100015542
 */
public class Finger {
    public Finger(Point p) {
        this.p = p;
    }
    
    public Finger() {
        this.p = new Point(0, 0);
    }
    
    private Point p;

    public Point getP() {
        return p;
    }

    public void setP(Point p) {
        this.p = p;
    }
}
