/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend_models;

//import org.opencv.Frame;
import org.opencv.core.Mat;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;

//import org.bytedeco.javacv.FrameGrabber;
//import org.bytedeco.javacv.OpenCVFrameConverter;
//import org.bytedeco.javacv.OpenCVFrameGrabber;
//import org.bytedeco.opencv.opencv_core.IplImage;
//import org.bytedeco.javacv.CanvasFrame;
//import org.bytedeco.javacv.VideoInputFrameGrabber;
//import org.bytedeco.opencv.opencv_videoio.VideoCapture;
/**
 *
 * @author erick
 */
public class VideoAnalyzer {

    public Mat getDisplayFrame() throws Exception {
        switch (this.camID) {
            case 0:
                return this.outputFrame;
            case 1:
                return this.foreground;
            case 2:
                return this.handMask;
            case 3:
                return this.debug;
        }
        return this.outputFrame;
    }

    public Mat getOutputFrame() throws Exception {
        if (this.init) {
            vc.retrieve(this.outputFrame);
            return this.outputFrame;
        }
        throw new Exception("Camera not opened");
    }

    public Mat getForeground() {
        return foreground;
    }

    public Mat getHandMask() {
        return handMask;
    }

    public Mat getDebug() {
        return debug;
    }

    private Mat outputFrame, foreground, handMask, debug;

    public FingerCount getFingerCount() {
        return this.fingerCount;
    }

    public FaceDetector getFaceDetector() {
        return this.faceDetector;
    }

    public BackgroundRemover getBackgroundRemover() {
        return this.backgroundRemover;
    }

    public SkinDetector getSkinDetector() {
        return this.skinDetector;
    }
    private final FingerCount fingerCount;
    private final FaceDetector faceDetector;
    private final BackgroundRemover backgroundRemover;
    private final SkinDetector skinDetector;
    private int camID = 0;

    public int getCamID() {
        return camID;
    }

    public void setCamID(int camID) {
        this.camID = camID;
    }

    public void camIDPlusOne() {
        ++this.camID;
        if (this.camID > 3) {
            this.camID = 0;
        }
    }
    private int cam = 0;

    public void setCam(int cam) {
        this.cam = cam;
    }
    private static VideoCapture vc;
    private boolean init = false;

    public int getCam() {
        return cam;
    }

    public boolean isInit() {
        return init;
    }

    public VideoAnalyzer(VideoCapture vc) throws Exception {
        this.fingerCount = new FingerCount();
        this.faceDetector = new FaceDetector();
        this.backgroundRemover = new BackgroundRemover();
        this.skinDetector = new SkinDetector();
        VideoAnalyzer.vc = vc;
        VideoAnalyzer.vc.set(Videoio.CAP_PROP_SETTINGS, 0);
        if (!VideoAnalyzer.vc.isOpened()) {
            this.init = false;
            throw new Exception("Camera id not valid");
        }
        this.init = true;
        this.outputFrame = new Mat();
        this.foreground = new Mat();
        this.handMask = new Mat();
        this.debug = new Mat();
    }

    public VideoAnalyzer(int cam) throws Exception {
        this.fingerCount = new FingerCount();
        this.faceDetector = new FaceDetector();
        this.backgroundRemover = new BackgroundRemover();
        this.skinDetector = new SkinDetector();
        VideoAnalyzer.vc = new VideoCapture(cam);
        VideoAnalyzer.vc.set(Videoio.CAP_PROP_SETTINGS, 0);
        if (!VideoAnalyzer.vc.isOpened()) {
            this.init = false;
            throw new Exception("Camera id not valid");
        }
        this.init = true;
        this.outputFrame = new Mat();
        this.foreground = new Mat();
        this.handMask = new Mat();
        this.debug = new Mat();
    }

    public VideoAnalyzer() throws Exception {
        this.cam = 0;
        this.fingerCount = new FingerCount();
        this.faceDetector = new FaceDetector();
        this.backgroundRemover = new BackgroundRemover();
        this.skinDetector = new SkinDetector();
        VideoAnalyzer.vc = new VideoCapture(this.cam);
        VideoAnalyzer.vc.set(Videoio.CAP_PROP_SETTINGS, 0);
        if (!VideoAnalyzer.vc.isOpened()) {
            for (; !VideoAnalyzer.vc.isOpened() && this.cam < 4; ++this.cam) {
                ++this.cam;
                VideoAnalyzer.vc = new VideoCapture(this.cam);
            }
        }
        if (!VideoAnalyzer.vc.isOpened()) {
            throw new RuntimeException("No camera opened");
        }
        this.init = true;
        this.outputFrame = new Mat();
        this.foreground = new Mat();
        this.handMask = new Mat();
        this.debug = new Mat();
    }

    public void traceFrame() throws Exception {
        Mat instant = this.getOutputFrame(), frameOut = new Mat();
        this.skinDetector.drawSkinColorSampler(instant);
        this.foreground = backgroundRemover.getForeground(instant);

        this.faceDetector.removeFaces(instant, this.foreground);
        this.handMask = this.skinDetector.getSkinMask(this.foreground);

        this.debug = fingerCount.findFingersCount(this.handMask, frameOut);
    }

}
