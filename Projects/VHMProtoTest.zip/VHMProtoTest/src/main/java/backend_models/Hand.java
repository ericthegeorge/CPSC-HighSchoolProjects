/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package backend_models;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import org.opencv.core.Point;

/**
 *
 * @author 1100015542
 */
public class Hand {

    private ArrayList<Finger> fingers;
    private int fingersUpLast;
    public ArrayList<Finger> getFingers() {
        return fingers;
    }

    public void setFingers(ArrayList<Finger> fingers) {
        this.fingers = fingers;
    }

    public int getFingersUpLast() {
        return fingersUpLast;
    }

    public void setFingersUpLast(int fingersUpLast) {
        this.fingersUpLast = fingersUpLast;
    }

    public Hand(Finger... fingers) {
        this.fingersUpLast = 0;
        Finger[] temp = fingers;
        this.fingers = (ArrayList<Finger>) Arrays.asList(temp);
    }

    public Finger getFinger(int tag) {
        return fingers.get(tag);
    }

//    public void organizeHand() {
//        Finger[] temp = (Finger[]) this.fingers.toArray();
//        Arrays.sort(temp, (Object o1, Object o2) -> {
//            Finger f1 = (Finger) o1;
//            Finger f2 = (Finger) o2;
//            return f1.getTag() - f2.getTag();
//        });
//        this.fingers = (ArrayList<Finger>) Arrays.asList(temp);
//    }

    public void addFinger(Finger f) {
        this.fingers.add(f);
//        this.organizeHand();
    }

    public boolean removeFinger() {
        if (fingers.size() <= 0) {
            return false;
        } else {
            fingers.remove(fingers.size() - 1);
            return true;
        }
    }

    public void clearFingers() {
        while (fingers.size() > 0) {
            fingers.remove(fingers.size() - 1);
        }
    }
    
    public void removeFingersFromIndx(int tag) {
        while (fingers.size() > tag + 1) {
            fingers.remove(fingers.size() - 1);
        }
    }
    public int getSize() {
        return fingers.size();
    }
}
