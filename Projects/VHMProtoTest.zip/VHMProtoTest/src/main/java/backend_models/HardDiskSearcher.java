/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend_models;

/**
 *
 * @author erick
 */
import java.io.File;

public class HardDiskSearcher {

    private boolean fileFound = false;
    public final static String OPENCV_LIB_NAME = "opencv_java455.dll";

    public HardDiskSearcher(String searchTerm, String systemBit) {
        this.searchTerm = searchTerm;
        this.systemBit = systemBit;
    }

    public HardDiskSearcher(String searchTerm) {
        this.searchTerm = searchTerm;
        this.systemBit = "64";
    }

    public boolean isFileFound() {
        return fileFound;
    }

    public void setFileFound(boolean fileFound) {
        this.fileFound = fileFound;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
    //opencv_java455.dll
    private String searchTerm;

    public String getSearchTerm() {
        return searchTerm;
    }

    public void setSearchTerm(String searchTerm) {
        this.searchTerm = searchTerm;
    }
    private String path;
    private String systemBit;

    public void setSystemBit(String bit) {
        this.systemBit = bit;
    }

    public String getSystemBit() {
        return this.systemBit;
    }

    public void findAndSetSystemType() {
        String systemProp = System.getProperty("com.ibm.vm.bitmode");
        if (systemProp != null) {
            if ("64".equals(systemProp)) {
                this.systemBit = systemProp;
                return;
            }
        }

        systemProp = System.getProperty("sun.arch.data.model");
        if (systemProp != null) {
            if ("64".equals(systemProp)) {
                this.setSystemBit(systemProp);
                return;
            }
        }

        systemProp = System.getProperty("java.vm.version");
        if (systemProp != null) {
            if ("64".equals(systemProp)) {
                this.setSystemBit(systemProp);
                return;
            }
        }
        this.setSystemBit("86");
    }

    public void recursiveSearchWithSystemBit(String searchTerm, File... files) {

        for (File file : files) {

            if (file.isDirectory()) {
                File[] filesInFolder = file.listFiles();
                if (filesInFolder != null) {
                    for (File f : filesInFolder) {
                        if (f.isFile()) {
                            if (this.isTheSearchedFileWithSystemBit(f, searchTerm)) {
                                this.fileFound = true;
                                return;
                            }
                        } else {
                            this.recursiveSearchWithSystemBit(searchTerm, f);
                        }
                    }
                }
            } else if (this.isTheSearchedFileWithSystemBit(file, searchTerm)) {
                this.fileFound = true;
                return;
            }
        }
    }

    public void recursiveSearchWithSystemBit(File... files) {

        for (File file : files) {

            if (file.isDirectory()) {
                File[] filesInFolder = file.listFiles();
                if (filesInFolder != null) {
                    for (File f : filesInFolder) {
                        if (f.isFile()) {
                            if (this.isTheSearchedFileWithSystemBit(f, this.searchTerm)) {
                                this.fileFound = true;
                                return;
                            }
                        } else {
                            this.recursiveSearchWithSystemBit(f);
                        }
                    }
                }
            } else if (this.isTheSearchedFileWithSystemBit(file, this.searchTerm)) {
                this.fileFound = true;
                return;
            }
        }
    }

    private boolean isTheSearchedFileWithSystemBit(File file, String searchTerm) {
        if (file.isFile() && (searchTerm.equals(file.getName())) && file.getParent().contains(this.systemBit)) {
            if (file.getParent().contains(this.systemBit)) {
                this.path = file.getAbsolutePath();
                return true;
            }
        }
        return false;
    }

    public void recursiveSearch(String searchTerm, File... files) {

        for (File file : files) {

            if (file.isDirectory()) {
                File[] filesInFolder = file.listFiles();

                if (filesInFolder != null) {
                    for (File f : filesInFolder) {
                        if (f.isFile()) {
                            if (this.isTheSearchedFile(f, searchTerm)) {
                                this.fileFound = true;
                                return;
                            }
                        }
                    }

                    for (File f : filesInFolder) {
                        if (f.isDirectory()) {
                            this.recursiveSearch(searchTerm, f);
                        }
                    }
                }
            } else if (this.isTheSearchedFile(file, searchTerm)) {
                this.fileFound = true;
                return;
            }
        }
    }

    public void recursiveSearch(File... files) {

        for (File file : files) {

            if (file.isDirectory()) {
                File[] filesInFolder = file.listFiles();

                if (filesInFolder != null) {
                    for (File f : filesInFolder) {
                        if (f.isFile()) {
                            if (this.isTheSearchedFile(f, this.searchTerm)) {
                                this.fileFound = true;
                                return;
                            }
                        }
                    }

                    for (File f : filesInFolder) {
                        if (f.isDirectory()) {
                            this.recursiveSearch(this.searchTerm, f);
                        }
                    }
                }
            } else if (this.isTheSearchedFile(file, this.searchTerm)) {
                this.fileFound = true;
                return;
            }
        }
    }

    private boolean isTheSearchedFile(File file, String searchTerm) {
        if (file.isFile() && (searchTerm.equals(file.getName()))) {
            this.path = file.getAbsolutePath();
            return true;
        }
        return false;
    }
}
