/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package backend_models;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.opencv.core.Mat;

/**
 *
 * @author 1100015542
 */
public class FrameUpdaterThread {
    private Thread t;

    public FrameUpdaterThread(VideoAnalyzer va) {
        this.va = va;
    }

    public Thread getT() {
        return t;
    }

    public void setT(Thread t) {
        this.t = t;
    }
    private Mat frame;
    private VideoAnalyzer va;
    private boolean play = true;

    public boolean isPlay() {
        return play;
    }

    public void setPlay(boolean play) {
        this.play = play;
    }
    
    public FrameUpdaterThread(VideoAnalyzer va, Runnable r) {
        this.va  = va;
        this.t = new Thread(r);
    }

    public Mat getFrame() {
        return frame;
    }

    public void setFrame(Mat frame) {
        this.frame = frame;
    }

    public VideoAnalyzer getVa() {
        return va;
    }

    public void setVa(VideoAnalyzer va) {
        this.va  = va;
    }

    public void start() {
        this.play = true;
        t.start();
    }

    public void stop() {
        this.play = false;
        t.interrupt();
    }
}
