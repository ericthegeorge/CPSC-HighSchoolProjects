/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frontend_viewcontroller;

import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import org.opencv.core.Mat;

/**
 *
 * @author 1100015542
 */
public class ModelsAndViewsController {

    /*
     *
     * ModelsAndViewsController needs to have an instance variable to reference
     * the backend's models because the frontend's ModelsAndViewsController is
     * responsible for asking the backend to modify its data.
     *
     * Since the backend models is initially set up by an instance of the
     * BackendModelSetup class, we just need this one instance variable here:
     */
    BackendModelSetup theBackendModel;
    /*
     *
     * This class also needs to have an instance variable to reference the
     * frontend's MainViewDisplay because the ModelsAndViewsController object is
     * responsible for asking the MainViewDisplay object to update itself.
     */
    MainViewDisplay theMainViewDisplay;

    /*
     *
     * Step 1 of 2 to provide user controls: write user action as private class
     * ------------------------------------------------------------------------
     *
     * User actions are written as private inner classes that implement
     * ActionListener, and override the actionPerformed method.
     *
     * Use the following as a template for writting more user actions.
     */

    private class CalibrateBackgroundRemovalAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                Mat input = theBackendModel.va.getDisplayFrame();
                theMainViewDisplay.calibrateBackgroundRemoval(input);
                theMainViewDisplay.updateFrame();
            } catch (Exception ex) {
                Logger.getLogger(ModelsAndViewsController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    private class CalibrateSkinDetectionAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                Mat input = theBackendModel.va.getDisplayFrame();
                theMainViewDisplay.calibrateSkinDetection(input);
                theMainViewDisplay.updateFrame();
            } catch (Exception ex) {
                Logger.getLogger(ModelsAndViewsController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    private class CalibrateAllAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                Mat input = theBackendModel.va.getDisplayFrame();
                theMainViewDisplay.calibrateSkinDetection(input);
                theMainViewDisplay.calibrateBackgroundRemoval(input);
                theMainViewDisplay.updateFrame();
            } catch (Exception ex) {
                Logger.getLogger(ModelsAndViewsController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    private class StartStopAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (theMainViewDisplay.startStopButton.getText().contains("Start")) {
                theMainViewDisplay.startUpdating();
                theMainViewDisplay.startStopButton.setText("Stop");
            } else {
                theMainViewDisplay.stopUpdating();
                theMainViewDisplay.startStopButton.setText("Start");
            }
        }
    }

    private class SwitchViewAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            theMainViewDisplay.stopUpdating();
            theBackendModel.va.camIDPlusOne();
            theMainViewDisplay.startUpdating();
        }
    }
    /*
     *
     * Constructor. Probably nothing for students to change.
     */
    public ModelsAndViewsController(BackendModelSetup aBackend, MainViewDisplay aMainViewDisplay) {
        this.theBackendModel = aBackend;
        this.theMainViewDisplay = aMainViewDisplay;
        this.initController();
    }

    /*
     *
     * Step 2 of 2 to provide user controls: wire user action to GUI widgets
     * ----------------------------------------------------------------------
     *
     * Once a private inner class has been written for a user action, you can
     * wire it to a GUI widget (i.e. one of the GUI widgets you created in the
     * MainViewDisplay class and which you gave a memorable variable name!).
     *
     * Use the following as templates for wiring in more user actions.
     */
    private void initController() {
        this.theMainViewDisplay.switchViewButton.addActionListener(new SwitchViewAction());
        this.theMainViewDisplay.calibrateAllButton.addActionListener(new CalibrateAllAction());
        this.theMainViewDisplay.calibrateBackgroundRemovalButton.addActionListener(new CalibrateBackgroundRemovalAction());
        this.theMainViewDisplay.calibrateSkinDetectionButton.addActionListener(new CalibrateSkinDetectionAction());
        this.theMainViewDisplay.startStopButton.addActionListener(new StartStopAction());
    }
}
