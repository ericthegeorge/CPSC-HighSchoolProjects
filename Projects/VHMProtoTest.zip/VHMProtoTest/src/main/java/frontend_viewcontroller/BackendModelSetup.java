/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frontend_viewcontroller;

/**
 *
 * @author 1100015542
 */
import backend_models.*;
import java.io.File;
import javax.swing.filechooser.FileSystemView;

public class BackendModelSetup {

    //TODO
     VideoAnalyzer va;
     RobotCursor rc;
     FrameUpdaterThread ft;
    //instantiate model

    public BackendModelSetup() throws Exception {
        //construct
        va  = new VideoAnalyzer();
        rc = new RobotCursor();
        ft = new FrameUpdaterThread(va);
        
        
        
        System.out.println("Initializing libraries");
        HardDiskSearcher mainLoaderSearcher = new HardDiskSearcher("opencv_java455.dll");
        mainLoaderSearcher.findAndSetSystemType();
        File[] systemRoots = File.listRoots();
        FileSystemView fsv = FileSystemView.getFileSystemView();

        for (File root : systemRoots) {
            if (fsv.getSystemTypeDescription(root).equals("Local Disk")) {
                System.out.println("Root: " + root.getName());
                mainLoaderSearcher.recursiveSearchWithSystemBit(root);
            }
        }
        if (mainLoaderSearcher.isFileFound()) {
            System.load(mainLoaderSearcher.getPath());
            System.out.println("Libraries initialized");
        }else {
            System.out.println("Liraries not initialized: " + mainLoaderSearcher.getPath());
        }
    }
}
