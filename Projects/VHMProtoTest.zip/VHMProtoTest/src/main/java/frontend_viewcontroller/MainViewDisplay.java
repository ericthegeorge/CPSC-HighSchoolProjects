/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frontend_viewcontroller;

/**
 *
 * @author 1100015542
 */
import backend_models.Finger;
import java.awt.*;
import java.awt.image.BufferedImage;
import org.opencv.core.MatOfByte;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;

public class MainViewDisplay extends JFrame {

    /*
     *
     * MainViewDisplay needs to have a instance variable to reference the
     * backend's models because the frontend's MainViewDisplay is responsible
     * for displaying data from the backend.
     *
     * Since the backend models is initially set up by an instance of the
     * BackendModelSetup class, we just need this one instance variable here:
     */
    BackendModelSetup theBackendModel;

    /*
     *
     * Step 1 of 4 for creating GUI widgets: declare them
     * --------------------------------------------------
     *
     * GUI widgets to be displayed to the user on the screen is declared here
     * (but will be constructed and initialized in the initComponents method).
     * The user will see data and can later interact with these widgets.
     */
    JLabel imageLabel;
    JButton calibrateBackgroundRemovalButton;
    JButton calibrateSkinDetectionButton;
    JButton startStopButton;
    JButton switchViewButton;
    JButton calibrateAllButton;

    /*
     *
     * Constructor. Probably nothing for students to change.
     */
    public MainViewDisplay(BackendModelSetup aBackend) {
        this.theBackendModel = aBackend;
        this.initComponents();
    }

    /*
     *
     * initComponents is all about fulfilling Responsibility #1 of this class:
     * (1) Construct the graphical user interface (GUI) on the screen
     */
    private void initComponents() {
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        /*
         *
         * Step 2 of 4 for creating GUI widgets: construct them
         * ----------------------------------------------------
         *
         * Construct GUI widget components here, and add them into the
         * mainDisplayPane later
         */
        this.imageLabel = new JLabel();
        this.imageLabel.setIcon((Icon) new BufferedImage(255, 255, 255));

        this.calibrateBackgroundRemovalButton = new JButton();
        this.calibrateBackgroundRemovalButton.setText("Calibrate Background Removal");

        this.calibrateSkinDetectionButton = new JButton();
        this.calibrateSkinDetectionButton.setText("Calibrate Skin Detection");

        this.calibrateAllButton = new JButton();
        this.calibrateAllButton.setText("Calibrate All");

        this.startStopButton = new JButton();
        this.startStopButton.setText("Start");

        this.switchViewButton = new JButton();
        this.switchViewButton.setText("Switch Video View");

        /*
         * Choose your LayoutManager for the mainDisplayPane here. See:
         * http://docs.oracle.com/javase/tutorial/uiswing/layout/visual.html
         *
         * I suggest GridBagLayout. For more details, see:
         * http://docs.oracle.com/javase/tutorial/uiswing/layout/gridbag.html
         */
        Container mainDisplayPane = this.getContentPane();
        mainDisplayPane.setLayout(new GridBagLayout());


        /*
         * you should construct a new GridBagConstraints object each time you
         * use it, in order to avoid subtle bugs...
         */
        GridBagConstraints gbc;


        /*
         *
         * Step 3 of 4 for creating GUI widgets: add them to the pane
         * ----------------------------------------------------------
         *
         * For each GUI widget you constructed earlier, you will now specify a
         * GridBagConstraints for it, then add the widget into the
         * mainDisplayPane
         */
        gbc = new GridBagConstraints(); // construct a new GridBagConstraints each time you use it, to avoid subtle bugs...
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 5;
        gbc.gridheight = 3;
        gbc.weightx = 0.5;
        gbc.weighty = 0.5;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.PAGE_START;

// then add your widget to the pane or component with the above settings
        mainDisplayPane.add(this.imageLabel, gbc);

        gbc = new GridBagConstraints(); // construct a new GridBagConstraints each time you use it, to avoid subtle bugs...
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0.2;
        gbc.weighty = 0.2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.PAGE_START;

// then add your widget to the pane or component with the above settings
        mainDisplayPane.add(this.calibrateSkinDetectionButton, gbc);

        gbc = new GridBagConstraints(); // construct a new GridBagConstraints each time you use it, to avoid subtle bugs...
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0.2;
        gbc.weighty = 0.2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.PAGE_START;

// then add your widget to the pane or component with the above settings
        mainDisplayPane.add(this.calibrateBackgroundRemovalButton, gbc);

        gbc = new GridBagConstraints(); // construct a new GridBagConstraints each time you use it, to avoid subtle bugs...
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0.2;
        gbc.weighty = 0.2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.PAGE_START;

        mainDisplayPane.add(this.calibrateAllButton, gbc);

        gbc = new GridBagConstraints(); // construct a new GridBagConstraints each time you use it, to avoid subtle bugs...
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        gbc.weightx = 0.2;
        gbc.weighty = 0.2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.anchor = GridBagConstraints.PAGE_START;

// then add your widget to the pane or component with the above settings
        mainDisplayPane.add(this.startStopButton, gbc);

        this.pack(); // leave this line last in this method.
        // must pack this JFrame before it can be displayed on screen
    }

    /*
     *
     * Step 4 of 4 for creating GUI widgets: write methods to update them
     * -------------------------------------------------------------------
     *
     * The methods below are all about fulfilling Responsibility #2 of this
     * class: (2) Pull data from the backend to display in the GUI
     *
     * Write below all the methods for displaying data into the GUI using this
     * MainViewDisplay object
     */
    void updateFrame() {
        Mat m = new Mat();
        try {
            this.theBackendModel.va.traceFrame();
            Mat frame = this.theBackendModel.va.getDisplayFrame();
            BufferedImage bi = MainViewDisplay.matToImage(m);
            ImageIcon ii = new ImageIcon(bi);
            this.imageLabel.setIcon(ii);
        } catch (Exception ex) {
            Logger.getLogger(ModelsAndViewsController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
//TODO

    void startUpdating() {
        this.theBackendModel.ft.setPlay(true);
        this.theBackendModel.ft.setT(new Thread(new Runnable() {
            @Override
            public void run() {
                while (theBackendModel.ft.isPlay()) {
                    if (isShowing()) {
                        updateFrame();
                    }
                    //TODO find and use finger locs
                    int last = theBackendModel.va.getFingerCount()
                            .getHand()
                            .getFingersUpLast();
                    int curr = theBackendModel.va.getFingerCount()
                            .getHand()
                            .getFingers()
                            .size();
                    Finger followed;
                    //clicking
                    if (last == 1 && curr == 0) {
                        theBackendModel.rc.leftClickPress();
                    } else if (last == 0 && curr == 1) {
                        theBackendModel.rc.leftClickRelease();
                    } else if (last == 1 && curr == 2) {
                        theBackendModel.rc.rightClickPress();
                    } else if (last == 2 && curr == 1) {
                        theBackendModel.rc.rightClickRelease();
                    } else if (last == 1 && curr > 3) {
                        theBackendModel.rc.scrollClickPress();
                    } else if (last > 3 && curr == 1) {
                        theBackendModel.rc.scrollClickRelease();
                    }
                    //moving
                                        if (curr >= 2) {
                        followed = theBackendModel.va.getFingerCount().getHand().getFinger(1);
                        theBackendModel.rc.getT().interrupt();
                        theBackendModel.rc.glide((int) followed.getP().x, (int) followed.getP().y);
                    } else if (curr > 0) {
                        followed = theBackendModel.va.getFingerCount().getHand().getFinger(0);
                        theBackendModel.rc.getT().interrupt();
                        theBackendModel.rc.glide((int) followed.getP().x, (int) followed.getP().y);
                    }

                }
            }
        }));
        this.theBackendModel.ft.start();
    }

    void stopUpdating() {
        if (this.theBackendModel.ft.isPlay()) {
            this.theBackendModel.ft.stop();
            this.theBackendModel.ft.setPlay(false);
        }
    }

    private static BufferedImage matToImage(Mat m) throws IOException {
        MatOfByte mb = new MatOfByte();
        Imgcodecs.imencode(".jpg", m, mb);
        //Storing the encoded Mat in a byte array
        byte[] byteArray = mb.toArray();
        //Preparing the Buffered Image
        InputStream in = new ByteArrayInputStream(byteArray);
        BufferedImage bufImage = ImageIO.read(in);
        return bufImage;
    }

    String showSaveDialog() {
        JFileChooser jfc = new JFileChooser();
        int status = jfc.showSaveDialog(this);
        if (status == JFileChooser.APPROVE_OPTION) {
            File theFile = jfc.getSelectedFile();
            String thePath = theFile.getAbsolutePath();
            return thePath;
        }

        return null;
    }

    String showOpenDialog() {
        JFileChooser jfc = new JFileChooser();
        int status = jfc.showOpenDialog(this);
        if (status == JFileChooser.APPROVE_OPTION) {
            File theFile = jfc.getSelectedFile();
            String thePath = theFile.getAbsolutePath();
            return thePath;
        }

        return null;
    }

    void calibrateSkinDetection(Mat input) {
        this.theBackendModel.va.getSkinDetector().calibrate(input);
    }

    void calibrateBackgroundRemoval(Mat input) {
        this.theBackendModel.va.getBackgroundRemover().calibrate(input);
    }

    void calibrate(Mat input) {
        this.calibrateBackgroundRemoval(input);
        this.calibrateSkinDetection(input);
    }

    //TODO make class for multithreading 
    //the updates of the frame and add to model
//    synchronized void startUpdating() {
//        Thread t;
//        t = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                while (true)
//                updateFrame();
//            }
//            
//        });
//    }
}
