/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package innerclassinouter;

/**
 *
 * @author erick
 */
public class OuterClass {

    public void test() {
        int a = 2;
        InnerClass obj = new InnerClass(100);
        System.out.println(obj.icMethod());
    }

    private static int ocMethod() {
        return 10;
    }
    public static int ocDataMember = 3;
//***************************************************

    class InnerClass {

        InnerClass(int val) //constructor
        {
            icDataMember = val;
        }

        int icMethod() {
            return (icDataMember + ocMethod() + ocDataMember);
        }
        int icDataMember;
    }
//***************************************************

}
