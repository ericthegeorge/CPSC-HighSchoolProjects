/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stackll;

/**
 *
 * @author 1100015542
 */
public class StackCalculator extends StackLL {

    public void add() {
        double num2 = stack.pop();
        double num1 = stack.pop();
        stack.push(num1 + num2);
    }

    public void subtract() {
        double num2 = stack.pop();
        double num1 = stack.pop();
        stack.push(num1 - num2);
    }

    public void multiply() {
        double num2 = stack.pop();
        double num1 = stack.pop();
        stack.push(num1 * num2);
    }

    public void divide() {
        double num2 = stack.pop();
        double num1 = stack.pop();
        stack.push(num1 / num2);
    }
}
