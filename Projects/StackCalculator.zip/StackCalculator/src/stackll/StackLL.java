/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stackll;

import java.util.LinkedList;

/**
 *
 * @author 1100015542
 */
public class StackLL implements StackIntrfc{
    LinkedList<Double> stack = new LinkedList<>();

    /**
     *places parameter on top of stack as head of list
     * @param d
     */
    @Override
    public void push(double d){
        stack.push(d);    }
    
    @Override
    public double pop() {
        return stack.pop();
    }
    
    @Override
    public double peek() {
        return stack.peek();
    }
    
    @Override
    public int size() {
        return stack.size();
    }

    /**
     *Removes all elements and references in the list
     */
    @Override
    public void clear() {
        stack.clear();
    }
    
}
