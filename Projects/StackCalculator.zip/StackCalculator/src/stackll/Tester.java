/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stackll;

import java.util.Scanner;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StackCalculator calc = new StackCalculator();
        String input = "";
        while (!input.contains("Q")) {
            System.out.print("\nEnter number, math operation(+,-,*, or /), or Q to quit: ");
            input = sc.nextLine();
            if ("+-*/".contains(input)) {
                if (input.contains("+")) {
                    calc.add();
                }
                if (input.contains("-")) {
                    calc.subtract();
                }
                if (input.contains("*")) {
                    calc.multiply();
                }
                if (input.contains("/")) {
                    calc.divide();
                }
            } else if (!input.contains("Q")){
                calc.push(Double.parseDouble(input));
            }
        }
        System.out.println("\nThe answer is " + calc.stack.pop());
    }
}