/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package innerclassinmethod;

/**
 *
 * @author erick
 */
public class OuterClass {

    public static void main(String args[]) {
        class InnerClass {

            InnerClass(int val) //constructor
            {
                icDataMember = val;
            }

            int icMethod() {
                return (icDataMember + ocMethod() + ocDataMember);
//                return (icDataMember + ocMethod( ) + ocDataMember + a);//won't compile because a belongs to the main method which innerclass doesn't
                //have access to.
            }
            int icDataMember;
        }
        int a = 2;
        InnerClass obj = new InnerClass(100);
        System.out.println(obj.icMethod());
    }

    private static int ocMethod() {
        return 10;
    }
    public static int ocDataMember = 3;

    public static void ocMethod1() {
//        InnerClass obj = new InnerClass(50);//will not compile since innerclass is a class that only exist in otuerclass main method.
    }
}
