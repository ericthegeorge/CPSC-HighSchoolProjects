/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bst.find;

/**
 *
 * @author 1100015542
 */
public class BST {

    BstNode rootNode;

    public BST(int i) //constructor: Root node added at the time of creation of the tree
    {
        rootNode = new BstNode(i);
    }

    public void addNode(int i) {
        BstNode currentNode = rootNode;
        boolean finished = false;
        do {
            BstNode curLeftNode = currentNode.leftNode;
            BstNode curRightNode = currentNode.rightNode;
            int curIntData = currentNode.intData;
            if (i > curIntData) { //look down the right branch
                if (curRightNode == null) { //create a new node referenced with currentNode.rightNode
                    currentNode.rightNode = new BstNode(i);
                    finished = true;
                } else //keep looking by assigning a new current node one level down
                {
                    currentNode = curRightNode;
                }
            } else { //look down the left branch
                if (curLeftNode == null) { //create a new node referenced with currentNode.leftNode
                    currentNode.leftNode = new BstNode(i);
                    finished = true;
                } else { //keep looking by assigning a new current node one level down
                    currentNode = curLeftNode;
                }
            }
        } while (!finished);
    }

    public void traverseAndPrint(BstNode currentNode) {
        System.out.print("data = " + currentNode.intData);
//To aid in your understanding, you may want to just ignore this
//indented portion and just print the integer. In that case, change the
//line above to a println instead of a print.
        if (currentNode.leftNode == null) {
            System.out.print(" left = null");
        } else {
            System.out.print(" left = " + (currentNode.leftNode).intData);
        }
        if (currentNode.rightNode == null) {
            System.out.print(" right = null");
        } else {
            System.out.print(" right = " + (currentNode.rightNode).intData);
        }
        System.out.println("");
        if (currentNode.leftNode != null) {
            traverseAndPrint(currentNode.leftNode);
        }
        if (currentNode.rightNode != null) {
            traverseAndPrint(currentNode.rightNode);
        }
    }

    public boolean find(int target) {
        BstNode curr = this.rootNode;
        while (curr != null) {
            if (curr.intData == target) {
                return true;
            }else if (curr.intData > target) {
                curr = curr.leftNode;
            }else {
                curr = curr.rightNode;
            }
        }
        return false;

    }
}
