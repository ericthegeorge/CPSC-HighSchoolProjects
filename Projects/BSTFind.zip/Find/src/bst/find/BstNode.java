/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bst.find;

/**
 *
 * @author 1100015542
 */
public class BstNode {

    public BstNode(int i) //Constructor
    {
        leftNode = null;
        rightNode = null;
        intData = i;
    }
    public int intData;
    public BstNode leftNode;
    public BstNode rightNode;
}
