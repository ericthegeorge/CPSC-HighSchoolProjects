/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bst.find;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BST bstObj = new BST(50);
        bstObj.addNode(56);
        bstObj.addNode(52);
        bstObj.addNode(25);
        bstObj.addNode(74);
        bstObj.addNode(54);
        System.out.println(bstObj.find(74));
        System.out.println(bstObj.find(13));
    }

}
