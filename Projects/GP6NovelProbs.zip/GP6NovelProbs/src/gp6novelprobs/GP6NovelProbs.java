/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gp6novelprobs;

import java.io.IOException;

/**
 *
 * @author 1100015542
 */
public class GP6NovelProbs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        String fileContent = new TextFile("Adventures_of_Sherlock_Holmes.txt").fileContent;
        CharProbability[] charProbs = CryptoAnalysis.charProbabilitiesOf(fileContent);
        float sum = 0;
        for (int i = 0; i < charProbs.length; i++){
            System.out.println(charProbs[i].toString());
            sum += charProbs[i].getProbability();
        }
        System.out.println("sum = " + sum);
        
    }
    
}
