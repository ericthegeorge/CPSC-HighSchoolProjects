package gp6novelprobs;

import java.util.Scanner;

public class CryptoAnalysis {

    public static CharFrequency[] charFrequenciesOf(String theTextStr) {
        CharFrequency[] charFreqs = new CharFrequency[10 + 26 + 26]; // 0 to 9, a to z, A to Z
        //nums
        for (int i = 0; i < 10; i++){
            charFreqs[i] = new CharFrequency((char) (i + 48));
        }
        //low letter
        for (int i = 0; i < 26; i++){
            charFreqs[i + 10] = new CharFrequency((char) (i + 97));
        }
        //up letter
                for (int i = 0; i < 26; i++){
            charFreqs[i + 10 + 26] = new CharFrequency((char) (65 + i));
        }
        
        for (int i = 0; i < theTextStr.length(); i ++){
            char current = theTextStr.charAt(i);
            
            for (int j = 0; j < charFreqs.length; j++){
                CharFrequency currentCharFreq = charFreqs[j];
                if (currentCharFreq.getChar() == current) {
                    currentCharFreq.plusOne();
                }
            }
        }
        return charFreqs;
    }
    
    public static CharProbability[] charProbabilitiesOf(String theTextStr) {
        CharFrequency[] charFreqs = charFrequenciesOf(theTextStr);
        int totalLetterCount = 0;
        for (int i = 0; i < charFreqs.length; i++){
            totalLetterCount += charFreqs[i].getFrequency();
        }
        CharProbability[] charProbs = new CharProbability[charFreqs.length];
        for (int i = 0; i < charFreqs.length; i++) {
            charProbs[i] = new CharProbability(charFreqs[i].getChar(), (float) charFreqs[i].getFrequency() / (float) totalLetterCount);
        }
           return charProbs;     
    }
}


