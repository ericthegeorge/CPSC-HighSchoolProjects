

/**
 * This is a class that tests the Deck class.
 */
public class DeckTester {

	/**
	 * The main method in this class checks the Deck operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		/* *** TO BE IMPLEMENTED IN ACTIVITY 2 *** */
                String[] ranks = {"ace", "2", "3", "jack"};
                String[] suits = {"spades", "clovers", "hearts", "diamonds"};
                int[] points = {1,2,3,11};
                Deck deck = new Deck(ranks, suits, points);
                System.out.println(deck.size());
//                System.out.println(deck.toString());
                Card c = deck.deal();
                System.out.println(c.toString());
                System.out.println(deck.size());
                System.out.println(deck.toString());
                deck.deal();
                deck.deal();
                deck.deal();
                System.out.println(deck.isEmpty());
	}
}
