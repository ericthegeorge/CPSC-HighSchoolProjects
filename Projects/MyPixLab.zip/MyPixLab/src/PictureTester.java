
/**
 * This class contains class (static) methods
 * that will help you test the Picture class
 * methods.  Uncomment the methods and the code
 * in the main to test.
 *
 * @author Barbara Ericson
 */
public class PictureTester {

    /**
     * Method to convert to black and white
     */
    public static void convertToBlackAndWhite() {
        Picture pic = new Picture("images/femaleLionAndHall.jpg");
        pic.explore();
        Pixel[][] pixels = pic.getPixels2D();
        for (Pixel[] rowArray : pixels) {
            for (Pixel pixObj : rowArray) {
                pixObj.setRed((int) pixObj.getAverage());
                pixObj.setGreen((pixObj.getRed()));
                pixObj.setBlue((int) pixObj.getGreen());

            }
        }
        pic.explore();
    }

    /**
     * Method to mirror image vertically
     */
    public static void verticalMirror() {
        Picture pic = new Picture("images/redMotorcycle.jpg");
        pic.explore();
        Pixel[][] pixels = pic.getPixels2D();
        for (int i = 0; i < pixels.length; i++) {
            for (int j = 0; j < pixels[i].length / 2; j++) {
                pixels[i][pixels[i].length - j - 1].setRed(pixels[i][j].getRed());
                pixels[i][pixels[i].length - j - 1].setGreen(pixels[i][j].getGreen());
                pixels[i][pixels[i].length - j - 1].setBlue(pixels[i][j].getBlue());
            }
        }
        pic.explore();
    }

    /**
     * Method to mirror image horizontally
     */
    public static void horizontalMirror() {
        Picture pic = new Picture("images/redMotorcycle.jpg");
        pic.explore();
        Pixel[][] pixels = pic.getPixels2D();
        for (int j = 0; j < pixels[0].length; j++) {
            for (int i = 0; i < pixels.length / 2; i++) {
                pixels[pixels.length - i - 1][j].setRed(pixels[i][j].getRed());
                pixels[pixels.length - i - 1][j].setGreen(pixels[i][j].getGreen());
                pixels[pixels.length - i - 1][j].setBlue(pixels[i][j].getBlue());
            }
        }
        pic.explore();
    }

    /**
     * Method to adjust brightness
     */
    public static void adjustBrightness(double adjustment) {
        double reset = adjustment;
        Picture pic = new Picture("images/koala.jpg");
        pic.explore();
        Pixel[][] pixels = pic.getPixels2D();

        //Getting brightest RGB value
        for (Pixel[] rowArray : pixels) {
            for (Pixel pixObj : rowArray) {
                if (pixObj.getRed() * adjustment > 255) {

                    adjustment = (double) 255 / (double) pixObj.getRed();
                }
                if (pixObj.getGreen() * adjustment > 255) {
                    adjustment = (double) 255 / (double) pixObj.getGreen();
                }
                if (pixObj.getBlue() * adjustment > 255) {
                    adjustment = (double) 255 / (double) pixObj.getBlue();
                }
                pixObj.setRed((int) (adjustment * pixObj.getRed()));
                pixObj.setGreen((int) (adjustment * pixObj.getGreen()));
                pixObj.setBlue((int) (adjustment * pixObj.getBlue()));
                adjustment = reset;
            }
        }
        //System.out.println(adjustment);
        //Applying Adjustment
//        for (Pixel[] rowArray : pixels) {
//            for (Pixel pixObj : rowArray) {
//                pixObj.setRed((int) (adjustment * pixObj.getRed()));
//                pixObj.setGreen((int) (adjustment * pixObj.getGreen()));
//                pixObj.setBlue((int) (adjustment * pixObj.getBlue()));
//            }
//        }
        pic.explore();
    }

    /**
     * Method to flip whole image horizontally
     */
    public static void flipHorizontal() {
        Picture pic1 = new Picture("images/butterfly1.jpg");
        Pixel[][] pixels1 = pic1.getPixels2D();
        //necessary to prevent crossreferencing of Picture objects
        Picture pic2 = new Picture("images/butterfly1.jpg");
        Pixel[][] pixels2 = pic2.getPixels2D();

        pic1.explore();
        for (int i = 0; i < pixels1.length; i++) {
            for (int j = 0; j < pixels1[i].length; j++) {
                pixels2[i][pixels1[i].length - j - 1].setRed(pixels1[i][j].getRed());
                pixels2[i][pixels1[i].length - j - 1].setGreen(pixels1[i][j].getGreen());
                pixels2[i][pixels1[i].length - j - 1].setBlue(pixels1[i][j].getBlue());
            }
        }
        pic2.explore();

    }
    /**
     * Method to flip whole image vertically
     */
    public static void flipVertical(){
                Picture pic1 = new Picture("images/butterfly1.jpg");
        Pixel[][] pixels1 = pic1.getPixels2D();
        //necessary to prevent crossreferencing of Picture objects
        Picture pic2 = new Picture("images/butterfly1.jpg");
        Pixel[][] pixels2 = pic2.getPixels2D();

        pic1.explore();
        for (int i = 0; i < pixels1.length; i++) {
            for (int j = 0; j < pixels1[i].length; j++) {
                pixels2[pixels1.length - i - 1][j].setRed(pixels1[i][j].getRed());
                pixels2[pixels1.length - i - 1][j].setGreen(pixels1[i][j].getGreen());
                pixels2[pixels1.length - i - 1][j].setBlue(pixels1[i][j].getBlue());
            }
        }
        pic2.explore();
    }
    /**
     * Method to 'repair' temple
     */
    public static void repairTemple() {
                        Picture pic1 = new Picture("images/temple.jpg");
        Pixel[][] pixels1 = pic1.getPixels2D();
        //necessary to prevent crossreferencing of Picture objects
        Picture pic2 = new Picture("images/temple.jpg");
        Pixel[][] pixels2 = pic2.getPixels2D();

        pic1.explore();
        for (int i = 27; i <= 96; i++) {
            for (int j = 13; j <= 275; j++) {
                pixels2[i][pixels1[i].length - j - 1].setRed(pixels1[i][j].getRed());
                pixels2[i][pixels1[i].length - j - 1].setGreen(pixels1[i][j].getGreen());
                pixels2[i][pixels1[i].length - j - 1].setBlue(pixels1[i][j].getBlue());
            }
        }
        pic2.explore();
    }
    
    /**
     * Method to build Collage
     */
//    public static void assembleCollage() {
//        
//    }
    
    /**
     * Method to test zeroBlue
     */
    public static void testZeroBlue() {
        Picture beach = new Picture("images/beach.jpg");
        beach.explore();
        beach.zeroBlue();
        beach.explore();
    }

    /**
     * Method to test zeroRed
     */
    public static void testZeroRed() {
        Picture beach = new Picture("images/beach.jpg");
        beach.explore();
        beach.zeroRed();
        beach.explore();
    }

    /**
     * Method to test mirrorVertical
     */
    public static void testMirrorVertical() {
        Picture caterpillar = new Picture("caterpillar.jpg");
        caterpillar.explore();
        caterpillar.mirrorVertical();
        caterpillar.explore();
    }

    /**
     * Method to test mirrorTemple
     */
    public static void testMirrorTemple() {
        Picture temple = new Picture("temple.jpg");
        temple.explore();
        temple.mirrorTemple();
        temple.explore();
    }

    /**
     * Method to test the collage method
     */
    public static void testCollage() {
        Picture canvas = new Picture("images/640x480.jpg");
        canvas.createCollage();
        canvas.explore();
    }

    /**
     * Method to test edgeDetection
     */
    public static void testEdgeDetection() {
        Picture swan = new Picture("images/swan.jpg");
        swan.edgeDetection(10);
        swan.explore();
    }

    /**
     * Main method for testing. Every class can have a main method in Java
     */
    public static void main(String[] args) {
        // uncomment a call here to run a test
        // and comment out the ones you don't want
        // to run
        //testEdgeDetection();
        //testCollage();
        //repairTemple();
        //flipVertical();
        //flipHorizontal();
        //horizontalMirror();
        //verticalMirror();
        //adjustBrightness(1.2);
        //convertToBlackAndWhite();
        //testZeroBlue();
        //testZeroRed();
        //testKeepOnlyBlue();
        //testKeepOnlyRed();
        //testKeepOnlyGreen();
        //testNegate();
        //testGrayscale();
        //testFixUnderwater();
        //testMirrorVertical();
        //testMirrorTemple();
        //testMirrorArms();
        //testMirrorGull();
        //testMirrorDiagonal();
        //testCollage();
        //testCopy();
        //testEdgeDetection();
        //testEdgeDetection2();
        //testChromakey();
        //testEncodeAndDecode();
        //testGetCountRedOverValue(250);
        //testSetRedToHalfValueInTopHalf();
        //testClearBlueOverValue(200);
        //testGetAverageForColumn(0);
    }
}
