/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package divisiblebywhat;

import java.util.Arrays;

/**
 *
 * @author Eric
 */
public class DivisibleByWhat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        long t = System.nanoTime();
//        int[] h = divisorsOf(25);
//        for (int i = 0; i < h.length; i++) {
//            System.out.println(h[i]);
//        }
//        long e = System.nanoTime();
//        System.out.println((e-t) / 1000000000.0);
    }

    public static boolean isDivisorOf(int x, int d) {
        return x % d == 0;
    }

    public static int[] divisorsOf(int x) {
        int[] divisor = new int[(int) (Math.sqrt(x) + 1)];
        int[] codivisor = new int[(int) (Math.sqrt(x) + 1)];
        int count = 0;
        int coCount = 0;
        //getting first half lol and second ig
        for (int i = 1; i <= (int) Math.sqrt(x); ++i) {
            if (DivisibleByWhat.isDivisorOf(x, i)) {
                divisor[count] = i;
                ++count;
                if (x / i != i && x / i > i) {
                    codivisor[coCount] = x / i;
                    ++coCount;
                } 

            }
        }
        int[] arr = new int[count + coCount];
        int allCount = -1;
        for (int i = 0; i < count; ++i) {
                        allCount++;
            arr[allCount] = divisor[i];
        }
        for (int i = 0; i < coCount; ++i){
                        allCount++;
            arr[allCount] = codivisor[coCount - 1 - i];
        }
        return arr;
    }
}
