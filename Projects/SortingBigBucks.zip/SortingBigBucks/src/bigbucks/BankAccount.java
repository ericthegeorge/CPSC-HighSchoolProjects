/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bigbucks;

/**
 *
 * @author 1100015542
 */
public class BankAccount implements Comparable{

    public BankAccount(String nm, double amt) {
        name = nm;
        balance = amt;
    }

    public void deposit(double dp) {
        balance = balance + dp;
    }

    public void withdraw(double wd) {
        balance = balance - wd;
    }
    public String name;
    public double balance;
    
    @Override
    public int compareTo(Object o) {
        String s1 = this.name;
        String s2 = ((BankAccount) o).name;
        return s1.compareTo(s2);
    }
}
