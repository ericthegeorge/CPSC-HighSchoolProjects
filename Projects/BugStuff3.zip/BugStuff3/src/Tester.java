
import info.gridworld.grid.Location;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Location loc1 = new Location(4, 3);
        Location loc2 = new Location(3, 4);
        int rowValue = loc1.getRow();
        System.out.println(rowValue == 4? "true": "false");
        Location loc3 = loc2.getAdjacentLocation(Location.SOUTH);
        System.out.println(loc3.getRow() + " " + loc3.getCol());
        int dir = loc1.getDirectionToward(new Location(6, 5));
        System.out.println(dir);
    }

}
