/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author 1100015542
 */
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
import java.awt.Color;
public class DancingBugRunner {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ActorWorld aw = new ActorWorld();
        int[] arr = {2, 1 ,6 , 8,1, 7, 3};
        DancingBug db = new DancingBug(arr);
        aw.add(db);
        aw.show();
    }
    
}
