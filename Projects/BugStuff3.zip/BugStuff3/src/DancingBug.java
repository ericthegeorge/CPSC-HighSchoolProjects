
import info.gridworld.actor.Bug;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author 1100015542
 */
public class DancingBug extends Bug {

    private int indx = 0;
    private int[] length;

    public DancingBug(int[] length) {
        this.length = length;
    }

    @Override
    public void act() {
        if (canMove()) {
            move();
            for(int i = 0; i < length[indx]; ++i) {
                turn();
            }
            if (indx + 1 < length.length - 1) {
                ++indx;
            }else {
                indx = 0;
            }

        } else {
            turn();
        }
    }
}
