/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author 1100015542
 */
public class BlueBasedBug extends Bug {

    @Override
    public void act() {
        if (!this.canMove()) {
            //flower in front?? never occurs because it can move when flower there
            removeSelfFromGrid();
        } else{
            Grid<Actor> grid = this.getGrid();
            ArrayList<Actor> neighbours = grid.getNeighbors(this.getLocation());
            Iterator neighborI = neighbours.iterator();
            while(neighborI.hasNext()) {
//                Actor a = (Actor) neighborI.next();
//                if(neighborI.next() instanceof Flower){
//                    
//                }
            }
            ArrayList<Location> locList = grid.getOccupiedLocations();
            //getting closest flower
            Iterator i = locList.iterator();
//            Location locComp = (Location) i.next();
//            Location locNext = null;
//            int rCurr = this.getLocation().getRow();
//            int cCurr = this.getLocation().getCol();
            boolean flowerFound = false;
            int dir = 0;
            for (; i.hasNext() && !flowerFound;) {
                Location l = (Location) i.next();
                if (grid.get(l) instanceof Flower) {
                    dir = this.getLocation().getDirectionToward(l);
                    flowerFound = true;

                }
                this.setDirection(dir);
                this.move();

//                locComp = (Location) i.next();
//                int r = locComp.getRow();
//                int c = locComp.getCol();
//                if ()
//                
            }

        }

//	randomTurn();
//	if (!canMove()) {
//	    return;
//	}
//	move();
//
//	Location loc = getLocation();
//	Grid<Actor> grid = getGrid();
//	ArrayList<Actor> neighbors = grid.getNeighbors(loc);
//
//	for (int i=0; i<neighbors.size(); i++) {
//	    Actor actor = neighbors.get(i);
////	    System.out.println(actor);
//	}
//
//	for (Actor actor: neighbors) {
//	    if (actor instanceof Flower) {
//		
//	    }
//	}
    }

    /*
     * Turns left or right 45 degrees at random.
     */
    public void randomTurn() {
        if (Math.random() < 0.5) {
            turn(-45);
        } else {
            turn(45);
        }
    }

    /*
     * Turns the given number of degrees.
     */
    public void turn(int degrees) {
        setDirection(getDirection() + degrees);
    }
}
