
import info.gridworld.actor.Actor;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author 1100015542
 */
public class Jumper extends Actor {
    
    public Jumper() {
        
    }
    
    @Override
    public void act() {
        if (this.canJump()) {
            this.jump();
        }else {
            this.removeSelfFromGrid();
//            this.setDirection(this.getDirection() + 45);
        }
    }

    public boolean canJump() {
        Grid<Actor> gr = this.getGrid();
        if (gr == null) {
            return false;
        }
        Location loc = this.getLocation();
        Location next = loc.getAdjacentLocation(getDirection()).getAdjacentLocation(getDirection());
        if (!gr.isValid(next)) {
            return false;
        }
        if (!(gr.get(loc.getAdjacentLocation(getDirection())) instanceof Rock)){
            return false;
        } 
        Actor neighbor = gr.get(next);
        return (neighbor == null) || (neighbor instanceof Flower);
    }

    public void jump() {
        Grid<Actor> gr = this.getGrid();
        if (gr == null) {
            return;
        }
        Location loc = this.getLocation();
        Location next = loc.getAdjacentLocation(getDirection()).getAdjacentLocation(getDirection());
        if (gr.isValid(next)) {
            this.moveTo(next);
        } else {
            removeSelfFromGrid();
        }
    }
}
