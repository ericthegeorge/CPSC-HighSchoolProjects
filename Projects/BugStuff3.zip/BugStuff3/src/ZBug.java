
import info.gridworld.actor.Bug;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author 1100015542
 */
public class ZBug extends Bug {

    private int sideLength, steps, zPart = 0;

    public ZBug(int length) {
        this.steps = 0;
        this.sideLength = length;
        turn();
        turn();
    }

    @Override
    public void act() {

        if (this.steps < this.sideLength && canMove()) {
            move();
            this.steps++;
        } else {
            if (canMove()) {
                if (this.zPart == 0) {
                    turn();
                    turn();
                    turn();
                    ++this.zPart;
                    this.steps = 0;
                } else if (this.zPart == 1) {
                    turn();
                    turn();
                    turn();
                    turn();
                    turn();
                    this.zPart = -1;
                    this.steps = 0;
                }
            }
        }
    }
}
