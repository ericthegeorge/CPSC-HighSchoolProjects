
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author 1100015542
 */
public class JumperRunner {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ActorWorld aw = new ActorWorld();
        Jumper j = new Jumper();
        aw.add(new Location(5, 5), j);
        Jumper l = new Jumper();
        l.setDirection(180);
        aw.add(new Location (3, 5), l);
        aw.add(new Rock());
        aw.add(new Rock());
        aw.show();
    }
    
}
