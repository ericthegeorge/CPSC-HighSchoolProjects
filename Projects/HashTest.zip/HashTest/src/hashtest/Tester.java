/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hashtest;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] data = {17761103, 17761215, 17770321, 18120518, 18120725, 18610422, 18620124, 18631023};
        for (int i = 0; i < data.length; ++i) {
            System.out.println(data[i] + ">>>" + hashCode(data[i]));
        }
    }
    
    
    public static int hashCode(int key) {
        final int TABLE_SIZE = 75;
        return key % TABLE_SIZE;
    }
}
