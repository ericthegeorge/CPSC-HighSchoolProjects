
import info.gridworld.actor.Bug;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 1100015542
 */
public class CircleBug  extends Bug{
    private int sideLength, steps = 0;
    
    public CircleBug(int length) {
        this.steps = 0;
        this.sideLength = length;
        
    }
    @Override
    public void act(){
        if (this.steps < this.sideLength && canMove()){
            move();
            this.steps++;
        }else {
            turn();
            this.steps = 0;
        }
    }
}
