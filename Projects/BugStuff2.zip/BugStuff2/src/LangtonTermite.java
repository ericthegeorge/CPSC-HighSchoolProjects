/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 1100015542
 */
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class LangtonTermite extends Termite {

    @Override
    public void act() {
        if (getGrid() == null)
            return;
	
	if (seeFlower()) {
	    flower = null;
	    pickUpFlower();
	    turn(45);
	} else {
	    if (!hasFlower()) {
		createFlower();
	    }
	    throwFlower();
	    turn(-45);
	}
	move();
    
        
//        if (seeFlower()) {
//            pickUpFlower();
//            dropFlower();
//            turn(-90);
//            move();
//        } else {
//            if (!hasFlower()) {
//                createFlower();
//            }
//            throwFlower();
//            turn(90);
//            move();
//
//        }
    }

}
