/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 1100015542
 */
import info.gridworld.actor.Flower;
public class EternalFlower extends Flower{
    @Override
    public void act() {}
}
