/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 1100015542
 */
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class MyTermites extends Termite {

    @Override
    public void act() {
        if (getGrid() == null) {
            return;
        }
        if (seeFlower() && !hasFlower()) {
            pickUpFlower();
        }else if (seeFlower() && hasFlower()) {
            dropFlower();
        }
        if (hasFlower()) {
            dropFlower();
        }
        if (canMove()) {
            move();
        }
        randomTurn();
    }
    @Override
    public void randomTurn(){
        	if (Math.random() < 0.5) {
	    turn(-90);
	} else {
	    turn(90);
	}
    }
}
