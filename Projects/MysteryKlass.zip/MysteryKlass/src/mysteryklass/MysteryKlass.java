/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mysteryklass;

/**
 *
 * @author 1100015542
 */
public class MysteryKlass {

    private int s;

    /**
     * @return an instance of this class
     */
    public MysteryKlass(int s) {
        // hidden implementation code
    }

    /**
     * result() returns a positive number.
     *
     * @return a positive number
     */
    public double result() {
        // hidden implementation code
        return -1.0;
    }
}
