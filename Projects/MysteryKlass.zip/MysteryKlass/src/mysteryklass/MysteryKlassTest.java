/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mysteryklass;
/**
 *
 * @author 1100015542
 */
public class MysteryKlassTest {
    public void test() {
    MysteryKlass mk = new MysteryKlass(5);
        assert(mk.result() > 0) : "result is not positive";
    }
}
