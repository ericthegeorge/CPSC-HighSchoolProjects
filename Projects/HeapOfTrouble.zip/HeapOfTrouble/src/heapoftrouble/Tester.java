/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package heapoftrouble;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
int maxIndx = 0;
        char[] bu​ffer = new char[100];
        Scanner sc
                = new S​canner(
                        new File("HeapData.in.txt"));
        while (sc.hasNext()) {
            ++maxIndx;
            buffer[maxIndx] = sc.nextLine().charAt(0);
//            System.out.print(buffer[maxIndx]);
        }
        int rows = (int) Math.ceil(Math.log(maxI​ndx) / Math.log(2));
         f​or (int i = rows; i > 0; --i) {
             i​nt  l​eadSpaceAmt = (int) Math.pow(2, rows - (5 - i)) - 1;
//             System.out.println("lead amt: " + leadSpaceAmt);
            for (int j = 0; j < leadSpaceAmt; ++j) {
                System.out.print(" ");
            }
            for (int j = (int) Math.pow(2, 4 - i); j < (int) Math.pow(2, 5 - i); ++j) {
                System.out.print(buffer[j]);
                int midSpace​Amt = (int) Math.pow(2, rows - (4- i)) - 1;
//                System.out.println("Mid amt: " + midSpaceAmt);
                for (int a = 0; a < midSpaceAmt; ++a) {
                    System.out.print(" ");
                }
            }
            System.out.println("\n");
        }
    }
    
}
