package gp7sortedprobs;

/**
 *
 * @author Eric George
 */
public class EnDecrypter {    
    public static char[] encrypt(char[] plainText){
        char[] cipherText = new char[plainText.length]; // 1 is a dummy number
        for (int i = 0; i < plainText.length; i++){
            cipherText[i] = (char)(plainText[i] + 13);
        }
        return cipherText;
    }
    
    public static char[] decrypt(char[] cipherText){
        char[] plainText = new char[cipherText.length]; // 1 is a dummy number
        for (int i = 0; i < cipherText.length; i++){
            plainText[i] = (char)(cipherText[i] - 13);
        }
        return plainText;
    }
}
