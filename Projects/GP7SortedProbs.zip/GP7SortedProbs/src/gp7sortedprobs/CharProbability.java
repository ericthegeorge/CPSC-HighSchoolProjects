package gp7sortedprobs;

/**
 *
 * @author cheng
 */
public class CharProbability{

    private char letter;
    private float probability;

    public CharProbability(char letter) {
        this.letter = letter;
        this.probability = 0;
    }
    
    public CharProbability(char letter, float prob) {
        this.letter = letter;
        this.probability = prob;
    }
        
    public float getProbability() {
        return this.probability;
    }

    public char getChar() {
        return this.letter;
    }

    // there is no plusOne method!!
    
    @Override
    public String toString(){
        return this.letter + " = " + this.probability;
    }
}
