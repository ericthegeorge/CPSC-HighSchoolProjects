/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package stackll;

/**
 *
 * @author 1100015542
 */
public interface StackIntrfc {
    void push(double d);
    double pop();
    double peek();
    int size();
    void clear();
}
