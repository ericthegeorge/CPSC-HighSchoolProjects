/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package multikeysort;

/**
 *
 * @author 1100015542
 */
import java.io.File;
import java.io.IOException;//necessary for File and IOException 
import java.util.Scanner;
import java.util.StringTokenizer;//necessary for StringTokenizer and Scanner 

public class MultiKeySort {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

        Scanner sf = new Scanner(new File("Names_ages.txt"));
        int maxIndx = -1;
        String text[] = new String[1000];
        while (sf.hasNext()) {
            maxIndx++;
            text[maxIndx] = sf.nextLine();

        }
        sf.close();
        sort(text, maxIndx);
        for (int i = 0; i <= maxIndx; ++i) {
            Scanner sc = new Scanner(text[i]);
            System.out.println(sc.next() + " " +  sc.nextInt());
        }
    }

    public static void sort(String[] s, int maxIndx) {
        String min;
        int minIndex;
        int minAge;
        int compAge = 0;
        for (int i = 0; i <= maxIndx; ++i) {
            Scanner sc = new Scanner(s[i]);
            min = sc.next();
            minIndex = i;
            minAge = sc.nextInt();
            for (int j = i + 1; j <= maxIndx; ++j) // Find minimum   
            {
                sc = new Scanner(s[j]);
                String comp = sc.next();
                compAge = sc.nextInt();
                if (comp.compareTo(min) < 0) //salient feature    
                {
                    min = comp;
                    int temp = minAge;
                    minAge = compAge;
                    compAge = temp;
                    minIndex = j;
                }else if (comp.compareTo(min) == 0) {
                    if (minAge > compAge){
                        min = comp;
                    int temp = minAge;
                    minAge = compAge;
                    compAge = temp;
                    minIndex = j;
                    }
                }
            }
            s[minIndex] = s[i];  // swap  
            s[i] = min + ", " + minAge;
            //WORKS
        }
    }
}
