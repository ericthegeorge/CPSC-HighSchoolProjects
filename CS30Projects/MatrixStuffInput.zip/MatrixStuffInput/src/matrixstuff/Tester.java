/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrixstuff;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(new File("MatrixData.txt"));
        int maxIndx = -1;
        String buffer[] = new String[1000];
        while (sc.hasNext()) {
            ++maxIndx;
            buffer[maxIndx] = sc.nextLine();
        }
        sc.close();
        int m1r = 0, m1c = 0, m2r = 0, m2c = 0, arrNum = 0;
        for (int i = 0; i < maxIndx; ++i) {
            if (buffer[i].contains("matrix")) {
                ++arrNum;
            } else if (buffer[i].contains("row") && arrNum == 1) {
                ++m1r;
            } else if (buffer[i].contains("row") && arrNum == 2) {
                ++m2r;
            } else if (arrNum == 1 && m1r == 1) {
                ++m1c;
            } else if (arrNum == 2 && m2r == 1) {
                ++m2c;
            }
        }

        int[][] a = new int[m1r][m1c];
        int[][] b = new int[m2r][m2c];

        int offset = 2;

        for (int i = 0; i < m1r; ++i) {
            for (int j = 0; j < m1c; ++j) {
                a[i][j] = Integer.parseInt(buffer[offset + j]);
            }
            offset += m1c + 1;
        }

        offset += 1;
        for (int i = 0; i < m2r; ++i) {
            for (int j = 0; j < m2c; ++j) {
                b[i][j] = Integer.parseInt(buffer[offset + j]);
            }
            offset += m2c + 1;
        }
        
        int[][] c = MatrixMult.mult(a, b);
        for (int i = 0; i < c.length; ++i) {
            for (int j = 0; j < c[i].length; ++j) {
                System.out.print(c[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
