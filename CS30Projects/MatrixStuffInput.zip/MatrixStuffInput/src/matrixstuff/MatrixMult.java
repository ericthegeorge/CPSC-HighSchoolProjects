/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrixstuff;

/**
 *
 * @author 1100015542
 */
import java.util.Arrays;
import java.util.Scanner;

public class MatrixMult {

    public static int[][] mult(int[][] a, int[][] b) {
        int rowNum = a.length;
        int coloumnNum = b[0].length;
        int[][] productAry = new int[rowNum][coloumnNum];
        for (int i = 0; i < rowNum; i++) {
            Arrays.fill(productAry[i], 1    );
        }
        int sum = 0;

            for (int i = 0; i < b[0].length; ++i) {
                for (int j = 0; j < a.length; ++j){
                    for (int element = 0; element < a[j].length; ++element){
                        sum += a[j][element] * b[element][i];
                    }
                    productAry[j][i] = sum;
                    sum = 0;
                }
                
            }
        return productAry;
    }
}
