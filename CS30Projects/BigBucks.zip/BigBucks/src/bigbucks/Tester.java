/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bigbucks;

import java.util.ArrayList;
import java.util.ListIterator;
import java.util.Scanner;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<BankAccount> aryList = new ArrayList<>();
        String input = null;
        do {
            System.out.print("Please enter the name to whom the account belongs. (\"Exit\" to abort) ");
            input = sc.nextLine();
            String name = input;
            if (!input.equalsIgnoreCase("EXIT")) {
                System.out.print("Please enter the amount of the deposit. ");
                input = sc.nextLine();
                double deposit = Double.valueOf(input);
                BankAccount ba = new BankAccount(name, deposit);
                aryList.add(ba);
            }
        } while (!input.equalsIgnoreCase("EXIT"));
        BankAccount highest = aryList.get(0);
        ListIterator li = aryList.listIterator();
        while (li.hasNext()) {
            BankAccount ba = (BankAccount) li.next();
            if (highest.balance < ba.balance) {
                highest = ba;
            }
        }
        System.out.println("The account with the largest balance belongs to " + highest.name + ".");
        System.out.println("The amount is $" + highest.balance + ".");

    }

}
