/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asteroiddefencecorp;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author 1100015542
 */
public class AsteroidDefence {

    public static String downsize(String input) {       
        Scanner sc = new Scanner(input);
        int satNum = sc.nextInt();
        int[] xVal = new int[satNum];
        int[] yVal = new int[satNum];
        boolean[] bool = new boolean[satNum];
        for (int i = 0; sc.hasNext(); ++i){
            xVal[i] = sc.nextInt();
            yVal[i] = sc.nextInt();
        }

        
        /*
        finding closest point
        */
        
        double dY;
        double currRelativeHyp = 0;
        //round robin the sats
        for (int i = 0; i < satNum - 1; ++i) {
            dY = yVal[i];
            for (int j = i; j < satNum; ++j) {
                if (dY > currRelativeHyp){
                    bool[i] = true;
                }
            }
        }        
        /*
        Naive Way is to check each point
         */
//        for (int i = 0; i < 999999;++i) {
//            int localX1, localX2, closestToPointSat = 0;
//            double hyp1, hyp2;
//            for (int j = 1; j < satNum; ++j) {
//                localX1 = Math.abs(i - xVal[closestToPointSat]);
//                localX2 = Math.abs(i - xVal[j]);
//                hyp1 = Math.sqrt(localX1 * localX1 + yVal[closestToPointSat] * yVal[closestToPointSat]);
//                hyp2 = Math.sqrt(localX2 * localX2 + yVal[j] * yVal[j]);
//                if (hyp1 > hyp2) {
//                    closestToPointSat = j;
//                }
//            }
//            bool[closestToPointSat] = true;
//            System.out.println("Done amount of times: " + i + 1 + " for this sat" + closestToPointSat);
//        }
        
        /* 
        Idea 1 
        find each point on the line closest to all sats in new arrays of closest satPointX and Y
        if sat is closer to that point than the sat that has that point as closest, deem the latter sat as irrelevant
        */
        //whichever closest to a closestSatPoint is winner
//        while (!sorted) {
//            for (int i = 0; i < satNum - 1; i++) { //going through all the satellites except the last one
//                                //if there sat being checked is already valuable, skip that sat and go to next sat in first for loop
//
//                for (int j = 0; j < satNum; j++){
//                    boolean satIsUseful = true;
//                    if (i != j && satIsUseful){
//                currRelativeHyp = Math.sqrt(Math.pow(Math.abs(xVal[j] - xVal[i]), 2) + yVal[j] * yVal[j]);
//                System.out.println("Relative Hyp for sat " + j + " relative to closest Point for sat " + i + " is " + currRelativeHyp);
//                if (currRelativeHyp < yVal[i]){
//                    bool[j] = true;
//                    bool[i] = false;
//                    j = satNum;
//                }
//                    }
//                    //check if currRelative hyp is less than closest point sat
//                    // if so, deem that sat as useless and break for-loop
//                }
//            }
//        }
        
        
        
        
        
        
        
        
        StringBuilder sbRet = new StringBuilder();
        for(int i = 0; i < satNum; ++i) {
            if (bool[i]){
                sbRet.append("The satellite at (").append(xVal[i]).append(", ").append(yVal[i]).append(") may be needed.\n");
            }
        }
        return sbRet.toString();
    }
}
