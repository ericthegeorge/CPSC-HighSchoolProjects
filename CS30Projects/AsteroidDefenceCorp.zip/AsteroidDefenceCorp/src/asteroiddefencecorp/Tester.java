/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asteroiddefencecorp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        File in = new File("sats-2-10.in.txt");
//        int maxIndx = -1;
        Scanner sc = new Scanner(in);
        StringBuilder sb = new StringBuilder();
        while (sc.hasNext()) {
            sb.append(sc.nextLine() + "\n");
        }
        System.out.println(AsteroidDefence.downsize(sb.toString()));
        /* Should print
        The satellite at (12257, 88) may be needed.
        The satellite at (576966, 481633) may be needed.
        */
    }

}
