/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package selectionsort;

/**
 *
 * @author 1100015542
 */
public class SelectionSort {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        int theArray[] = {4, 2, 5, 1, 3, 18, 0, 9, 6};
        sort(theArray);
        for (int j = 0; j < theArray.length; j++) {
            System.out.print(theArray[j] + "   ");
        }
        System.out.println(" ");
    }

    public static void sort(int a[]) {
        int min, minIndex;
        for (int i = 0; i < a.length; ++i) {
            min = a[i];
            minIndex = i;
            for (int j = i + 1; j < a.length; ++j) {
                if (a[j] < min) {
                    min = a[j];
                    minIndex = j;
                }
            }
            a[minIndex] = a[i];
            a[i] = min;
        }
    }
}
