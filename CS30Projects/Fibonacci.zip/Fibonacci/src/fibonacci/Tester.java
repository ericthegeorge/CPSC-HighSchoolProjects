/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fibonacci;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;

public class Tester {

    public static void main(String args[]) {
        Scanner kbReader = new Scanner(System.in);
        System.out.print("Generate which term number? ");
        int k = kbReader.nextInt();
        System.out.println("Term #" + k + " is " + ModFib.modFibonacci(k));
    }
}
