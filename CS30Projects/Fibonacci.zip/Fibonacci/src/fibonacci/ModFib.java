/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fibonacci;

/**
 *
 * @author 1100015542
 */
public class ModFib {
    
    public static int modFibonacci(int term) {
        int n = 8;
        int nmin1 = 5;
        int nmin2 = 3;
        if (term == 1) {
            return nmin2;
        }else if (term == 2) {
            return nmin1;
        }
        
        for (int i = 3; i < term; ++i) {
            int sum = nmin1 + nmin2;
            nmin2 = nmin1;
            nmin1 = n;
            n+= sum;
        }
        return n;
    }
}
