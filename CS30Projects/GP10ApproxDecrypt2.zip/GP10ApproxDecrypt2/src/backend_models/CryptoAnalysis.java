package backend_models;

import java.util.Scanner;

public class CryptoAnalysis {

    public static CharFrequency[] charFrequenciesOf(String theTextStr) {
        
        
                CharFrequency[] charFreqs = new CharFrequency[141]; // 0 to 9, a to z, A to Z\
        for (int i = 0; i < charFreqs.length; i++) {
            if (i <= charFreqs.length) {
                CharFrequency charFreqency = new CharFrequency((char) (i), 0);
                charFreqs[i] = charFreqency;
            }
        }
        char[] theTextStrArray = theTextStr.toCharArray();
        for (int i = 0; i < theTextStrArray.length; i++) {
            char currentChar = theTextStrArray[i];
            for (int j = 0; j < charFreqs.length; j++) {
                CharFrequency currentCharFreq = charFreqs[j];
                if (currentCharFreq.getChar() == currentChar) {
                    charFreqs[j].plusOne();
                }
            }
        }

        return charFreqs;
//        char[] textArr = theTextStr.toCharArray();
//        CharFrequency[] charFreqs = new CharFrequency[141]; // 0 to 9, a to z, A to Z
//        //nums
//        for (int i = 0; i < 10; i++) {
//            if (i <= charFreqs.length) {
//            charFreqs[i] = new CharFrequency((char) i);
//            }
//        }
//
//        for (int i = 0; i < textArr.length; i++) {
//            char current = textArr[i]   ;
//            for (int j = 0; j < charFreqs.length; j++) {
//                CharFrequency currentCharFreq = charFreqs[j];
//                if (currentCharFreq.getChar() == current) {
//                    charFreqs[j].plusOne();
//                }
//            }
//        }
//        return charFreqs;
    }

    public static CharProbability[] charProbabilitiesOf(String theTextStr) {
        CharFrequency[] charFreqs = charFrequenciesOf(theTextStr);
        int totalLetterCount = 0;
        for (int i = 0; i < charFreqs.length; i++) {
            totalLetterCount += charFreqs[i].getFrequency();
        }
        CharProbability[] charProbs = new CharProbability[charFreqs.length];
        for (int i = 0; i < charFreqs.length; i++) {
            charProbs[i] = new CharProbability(charFreqs[i].getChar(), (float) charFreqs[i].getFrequency() / (float) totalLetterCount);
        }
        return charProbs;
    }

    public static CharProbability[] sortedCharProbabilitiesOf(String theTextStr) {
        CharProbability[] charProbs = charProbabilitiesOf(theTextStr);
        boolean sorted = false;
        while (sorted == false) {
            boolean swapped = false;
            for (int i = 0; i < charProbs.length - 1; i++) {
                CharProbability curr = charProbs[i];
                CharProbability next = charProbs[i + 1];
                if (curr.getProbability() < next.getProbability()) {
                    CharProbability temp = curr;
                    charProbs[i] = next;
                    charProbs[i + 1] = temp;
                    swapped = true;
                }

            }
            if (swapped == false) {
                sorted = true;
            }
        }
        int firstZeroIndx = -1;
        for (int i = 0; i < charProbs.length; i++) {
            if (charProbs[i].getProbability() == 0 && firstZeroIndx == -1){
                firstZeroIndx = i;
            }
        }
        
        CharProbability[] filteredCharProbs = new CharProbability[firstZeroIndx];
        for (int i = 0; i < firstZeroIndx; i ++){
            filteredCharProbs[i] = charProbs[i];
        }
        return charProbs;
    }
    
    public static String approxDecrypt(String cipherTxt, String charListSortedByProbabilties){
        CharProbability[] cipherCharListSortedByProbabilities = CryptoAnalysis.sortedCharProbabilitiesOf(cipherTxt);
        
        int maxMatchedUpLetterCount = charListSortedByProbabilties.length();
        if (maxMatchedUpLetterCount > cipherCharListSortedByProbabilities.length){
            maxMatchedUpLetterCount = cipherCharListSortedByProbabilities.length;
        }
        
        
        
        char[] cipherTxtArr = cipherTxt.toCharArray();
        for (int i = 0; i < cipherTxtArr.length; i++) {
            char currCipherChar = cipherTxtArr[i];
            
            int currCipherCharIndx = -1;
            for (int j = 0; j < maxMatchedUpLetterCount; j++) {
                if (cipherCharListSortedByProbabilities[j].getChar() == currCipherChar){
                    currCipherCharIndx = j;
                }
            }
            if (currCipherCharIndx > -1) {
            char decryptedChar = charListSortedByProbabilties.charAt(currCipherCharIndx);
            cipherTxtArr[i] = decryptedChar;
            }
        }
        
        String decryptedStr = new String(cipherTxtArr);
        return decryptedStr;
        
        
        
        
        
        
        
        
//        //cipherTxt = encrypted text
//        //charListSortedByProbabilites = sorted char probabilities of return string
//        CharProbability[] cipherCharListSortedByProbabilities = sortedCharProbabilitiesOf(cipherTxt);
//        for (int i = 0; i < cipherCharListSortedByProbabilities.length; i++){
//            //System.out.println(cipherCharListSortedByProbabilities[i].getChar());
//        }
////        System.out.println(charListSortedByProbabilties);
////            System.out.println(charListSortedByProbabilties.length());
//            char[] sortedCharList = new char[charListSortedByProbabilties.length()];
//            for(int i = 0; i < charListSortedByProbabilties.length(); i++) {
//                sortedCharList[i] = charListSortedByProbabilties.charAt(i);
//               // System.out.println(charListSortedByProbabilties.charAt(i));
//            }
//            //System.out.println(cipherTxt);
//            char[] cipherTxtArr = cipherTxt.toCharArray();
//            //System.out.println(cipherTxtArr[2]);
//            
//            StringBuilder sb = new StringBuilder();
//        for (int i = 0; i < cipherTxt.length(); i++){
//            char currChar = cipherTxtArr[i];
//            //System.out.println(currChar);
//            int indx = 0;
//            for (int j = 0; i < cipherCharListSortedByProbabilities.length; i ++){
//                if (cipherCharListSortedByProbabilities[j].getChar() == (currChar)){
//                    indx = j;
//            }
//                sb.append(sortedCharList[indx]);
//        }
//        }
//        //System.out.println(cipherCharListSortedByProbabilities[0].getChar());
//        //System.out.println(sb.toString());
//        return sb.toString();
    }
}
    
