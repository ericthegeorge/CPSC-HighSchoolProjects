package backend_models;

import java.util.Scanner;

public class CryptoAnalysis {

    public static CharFrequency[] charFrequenciesOf(String theTextStr) {
        CharFrequency[] charFreqs = new CharFrequency[10 + 26 + 26]; // 0 to 9, a to z, A to Z
        //nums
        for (int i = 0; i < 10; i++) {
            charFreqs[i] = new CharFrequency((char) (i + 48));
        }
        //low letter
        for (int i = 0; i < 26; i++) {
            charFreqs[i + 10] = new CharFrequency((char) (i + 97));
        }
        //up letter
        for (int i = 0; i < 26; i++) {
            charFreqs[i + 10 + 26] = new CharFrequency((char) (65 + i));
        }

        for (int i = 0; i < theTextStr.length(); i++) {
            char current = theTextStr.charAt(i);

            for (int j = 0; j < charFreqs.length; j++) {
                CharFrequency currentCharFreq = charFreqs[j];
                if (currentCharFreq.getChar() == current) {
                    currentCharFreq.plusOne();
                }
            }
        }
        return charFreqs;
    }

    public static CharProbability[] charProbabilitiesOf(String theTextStr) {
        CharFrequency[] charFreqs = charFrequenciesOf(theTextStr);
        int totalLetterCount = 0;
        for (int i = 0; i < charFreqs.length; i++) {
            totalLetterCount += charFreqs[i].getFrequency();
        }
        CharProbability[] charProbs = new CharProbability[charFreqs.length];
        for (int i = 0; i < charFreqs.length; i++) {
            charProbs[i] = new CharProbability(charFreqs[i].getChar(), (float) charFreqs[i].getFrequency() / (float) totalLetterCount);
        }
        return charProbs;
    }

    public static CharProbability[] sortedCharProbabilitiesOf(String theTextStr) {
        CharProbability[] charProbs = charProbabilitiesOf(theTextStr);
        boolean sorted = false;
        while (sorted == false) {
            boolean swapped = false;
            for (int i = 0; i < charProbs.length - 1; i++) {
                CharProbability curr = charProbs[i];
                CharProbability next = charProbs[i + 1];
                if (curr.getProbability() < next.getProbability()) {
                    CharProbability temp = curr;
                    charProbs[i] = next;
                    charProbs[i + 1] = temp;
                    swapped = true;
                }

            }
            if (swapped == false) {
                sorted = true;
            }
        };
        return charProbs;
    }
}
