/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package shiftingmarquee;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author 1100015542
 */
public class ShiftingMarquee {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(new File("Marquee.dat.txt"));
        while (sc.hasNextLine()) {
            int shiftNum = Integer.parseInt(sc.nextLine());
            System.out.println("shiftNum: " + shiftNum);
            String text = sc.nextLine();
            System.out.println("text: " + text);
            //char into list
            LinkedList<String> lst = new LinkedList<>();
            for (int i = 0; i < text.length(); ++i) {
                lst.addLast(text.charAt(i) + "");
            }
            for (int i = 0; i < shiftNum; ++i) {
                String popped = lst.removeFirst();
                lst.addLast(popped);
            }
            Iterator i = lst.iterator();
            while (i.hasNext()){
                System.out.print(i.next());
            }
            System.out.println("");
        }
    }

}
