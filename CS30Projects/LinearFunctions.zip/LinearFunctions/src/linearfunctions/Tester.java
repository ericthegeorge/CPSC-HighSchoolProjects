/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package linearfunctions;

import java.util.Scanner;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner kbReader = new Scanner(System.in);
        System.out.print("What is the slope of your line? ");
        double slope = kbReader.nextDouble();
        System.out.print("What is the y-intercept of your line? ");
        double yIntc = kbReader.nextDouble();
        LinearFunction line = new LinearFunction(slope, yIntc);
        System.out.println("\nSlope of this line is: " + line.getSlope());
        System.out.println("Y-intercept of this line is: " + line.getYintercept());
        System.out.println("Root of this line is: " + line.getRoot());
        System.out.print("\nWhat is an x value for which you wish to solve for y? ");
        double x = kbReader.nextDouble();
        double yValue = line.getYvalue(x);
        System.out.println("The y value corresponding to x = " + x + " is " + yValue);
        System.out.print("\nWhat is a y value for which you wish to solve for x? ");
        double y = kbReader.nextDouble();
        double xValue = line.getXvalue(y);
        System.out.println("The x value corresponding to y = " + y + " is " + xValue);
    }
}


