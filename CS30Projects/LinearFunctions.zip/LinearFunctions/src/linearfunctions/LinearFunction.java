/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package linearfunctions;

/**
 *
 * @author 1100015542
 */
public class LinearFunction implements LinearFunctionMethods{
    private double slope;
    private double yInt;
    public LinearFunction(double m, double b){
        this.slope = m;
        this.yInt = b;
    }
    @Override
    public double getSlope(){
        return this.slope;
    }
    @Override
    public double getYintercept() {
        return this.yInt;
    }
    @Override
    public double getRoot() {
        return -this.yInt / this.slope;
    }
    @Override
    public double getYvalue(double x){
        return this.slope * x + yInt;
    }
    @Override
    public double getXvalue(double y){
        return (y - this.yInt) / this.slope;
    }
}
