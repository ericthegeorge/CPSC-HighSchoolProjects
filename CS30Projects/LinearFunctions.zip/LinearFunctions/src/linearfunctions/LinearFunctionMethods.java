/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package linearfunctions;

/**
 *
 * @author 1100015542
 */
public interface LinearFunctionMethods {
    double getSlope();
    double getYintercept();
    double getRoot();
    
    double getYvalue(double x);
    double getXvalue(double y);
}
