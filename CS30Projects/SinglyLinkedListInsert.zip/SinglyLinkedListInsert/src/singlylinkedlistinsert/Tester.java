/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package singlylinkedlistinsert;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
//Creation of the nodes         
        Tester.append(0, "Pump station");
        Tester.append(3050, "Hwy 35");
        Tester.append(4573, "Tank farm");
// 3050 + 1523 = 4573     

        Tester.traverseAndPrint();

        System.out.println("******  now insert a node before old node 2  *******\n");
        Tester.insert(4040, "Cold Creek", 2); // 3050 + 990 = 4040                
        traverseAndPrint();
    }
    private static PipelineNode headNode = null;
    private static PipelineNode tailNode = null;

    //append a new node to the end of the list and adjust pointers     
    public static void append(int pos, String descr) {
        PipelineNode newNode = new PipelineNode(pos, descr, null);
        if (headNode == null) //There are no nodes yet so the node we          
        {
            //“append” will be both the head and the tail               
            headNode = newNode;
        } else {
            tailNode.nextNode = newNode;
//update the old tailNode      
        }
        tailNode = newNode; //specify a new tailNode   
    }

    public static void traverseAndPrint() {
        PipelineNode currentNode = headNode;
        int nodeNum = -1;
        do {
            nodeNum++;
            System.out.println("Node number: " + nodeNum);
            System.out.println("Position: " + currentNode.position);
            System.out.println("Description: " + currentNode.description);
            System.out.println("");  //gives a blank line between nodes              
            currentNode = currentNode.nextNode;
        } while (currentNode != null);  //We don't need to know ahead of time how many   
    }

    private static void insert(int pos, String descr, int indx) {
        PipelineNode newNode = new PipelineNode(pos, descr, null);
        if (indx == 0) {
            newNode.nextNode = headNode.nextNode;
            headNode = newNode;
        }

        int i = 0;
        PipelineNode curr = headNode;
        while (i + 1 < indx && curr.nextNode != null) {
            curr = curr.nextNode;
            ++i;
        }
        //add condtion to prepend newNode

        newNode.nextNode = curr.nextNode;
        curr.nextNode = newNode;
    }
}
