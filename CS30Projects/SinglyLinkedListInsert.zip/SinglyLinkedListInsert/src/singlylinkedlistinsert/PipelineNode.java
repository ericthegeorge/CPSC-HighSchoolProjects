/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package singlylinkedlistinsert;

/**
 *
 * @author 1100015542
 */
public class PipelineNode {

    public PipelineNode(int pos, String descr, PipelineNode ptr) //Constructor     
    {
        this.position = pos;
        this.description = descr;
        this.nextNode = ptr;
    }
    public int position;
    public String description;
    public PipelineNode nextNode;
}
