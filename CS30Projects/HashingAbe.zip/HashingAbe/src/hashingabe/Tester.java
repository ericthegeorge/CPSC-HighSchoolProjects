/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hashingabe;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String[] datas = {"Clinton, Bill", "Bush, George", "Washington, George", "Lincoln, Abraham"};
        for (int i = 0; i < datas.length; ++i) {
            System.out.println(datas[i] + ">>>" + hash(datas[i]));
        }
    }
    
    public static int hash(String data) {
        final int TABLE_SIZE = 180;
        data = data.toUpperCase();
        int keyInt;
        keyInt = data.charAt(0) * 1000;
        keyInt += data.charAt(1) * 100;
        keyInt += data.charAt(data.length() - 2) * 10;
        keyInt += data.charAt(data.length() - 1);
        return keyInt % TABLE_SIZE;
    }
    
}
