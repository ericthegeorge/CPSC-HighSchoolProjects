/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrixstuff;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][] a = { {1, 2, -2, 0}, {-3, 4, 7, 2}, {6, 0, 3, 1} };
        int[][]b = { {-1, 3}, {0, 9}, {1, -11}, {4, -5} };
        int[][] c = MatrixMult.mult(a, b);
        for (int i = 0; i < c.length; ++i) {
            for (int j = 0; j < c[i].length; ++j) {
                System.out.print(c[i][j] + "\t");
            }
            System.out.println();
        }
    }  
}
