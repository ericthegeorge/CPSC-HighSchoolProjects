/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bigbucks;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.ListIterator;
import java.util.Scanner;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
        BankAccount[] ba = new BankAccount[5];
        double d;
        String anInput;
        for (int i = 0; i < ba.length; ++i) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Please enter the name to whom the account belongs. ");
            anInput = sc.nextLine();
            System.out.print("Please enter the amount of the deposit. ");
            d = sc.nextDouble();
            ba[i] = new BankAccount(anInput, d);
        }
        Arrays.sort(ba, new BA_comparator());
        for (int i = 0; i < ba.length; ++i) {
            System.out.println(ba[i].name + ">>>" + ba[i].balance);
        }
    }

}
