/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bigbucks;

/**
 *
 * @author 1100015542
 */
import java.util.*;  //necessary for Comparator interface 

public class BA_comparator implements Comparator {

    @Override
    public int compare(Object firstObject, Object secondObject) {
        BankAccount ba1 = (BankAccount) firstObject;
        BankAccount ba2 = (BankAccount) secondObject;
        int retValue;
        if (ba1.balance < ba2.balance) {
            retValue = -1;
        } else {
            if (ba1.balance > ba2.balance) {
                retValue = 1;
            } else {
                retValue = 0;
            }
        }
        return retValue;
    }
}
