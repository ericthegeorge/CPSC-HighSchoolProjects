/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package binarysearch;

/**
 *
 * @author 1100015542
 */
public class BinarySearch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,14, 15, 16, 17 ,18, 19, 20};
        int target = 19;
        System.out.println(a[BinarySearch.binarySearch(a, target, 0, a.length - 1)]);
        
        
        
    }
    
    
    public static int binarySearch(int[] a, int target, int left, int right){
        int leftIndx = left;
        int rightIndx = right;
        int mid = (rightIndx / 2 + leftIndx / 2);
        if (a[mid] == target){
            return mid;
        }else if (target < a[mid]){
            return BinarySearch.binarySearch(a, target, 0, mid - 1);
        } else{
            return BinarySearch.binarySearch(a, target, mid + 1, a.length - 1);
        }
    }
    
}
