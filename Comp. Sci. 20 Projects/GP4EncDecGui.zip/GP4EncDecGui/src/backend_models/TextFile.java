package backend_models;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author Eric George
 */
public class TextFile {

    public String path;
    public String fileContent;

    public TextFile(String path) throws IOException { // throws IOException ?
        this.path = path;
        this.fileContent = readFile(this.path);

    }

    public void encrypt() throws IOException {
        this.fileContent = new String(EnDecrypter.encrypt(fileContent.toCharArray()));

    }

    public void decrypt() throws IOException {
        this.fileContent = new String(EnDecrypter.decrypt(fileContent.toCharArray()));

    }

    public void saveToDisk(String path) throws IOException {
        FileWriter fw = new FileWriter(path);
        PrintWriter pw = new PrintWriter(new FileWriter(path));
        pw.print(this.fileContent);
        fw.close();
        pw.close();
    }

    public static String readFile(String path) throws IOException { // throws IOException
        int maxIndx = -1;
        StringBuilder sb = new StringBuilder();
        Scanner sc = new Scanner(new File(path));
        while (sc.hasNext()) {
            maxIndx++;
            sb.append(sc.nextLine() + "\n");
        }
        return sb.toString();
    }
}
