/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encryptiondecryption;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;

public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner kbReader = new Scanner(System.in);
        System.out.print("Enter a sentence that is to be encrypted: ");
        String sntnc = kbReader.nextLine();
        System.out.println("Original sentence = " + sntnc);

        Encrypt myEncryptObj = new Encrypt(sntnc);
        String encryptdSntnc = myEncryptObj.Encrypter();
        System.out.println("Encrypted sentence = " + encryptdSntnc);

        Decrypt myDecryptObj = new Decrypt(encryptdSntnc);
        String decryptdSntnc = myDecryptObj.Decrypter();
        System.out.println("Decrypted sentence = " + decryptdSntnc);
    }

}
