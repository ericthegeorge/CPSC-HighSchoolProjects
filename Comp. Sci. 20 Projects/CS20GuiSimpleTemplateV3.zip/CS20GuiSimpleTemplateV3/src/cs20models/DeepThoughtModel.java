package cs20models;

/**
 * A class to model the problem or situation your program solves
 * 
 * @author cheng
 */
public class DeepThoughtModel {

    private String aNiceThought;

    public DeepThoughtModel() {
        this.aNiceThought = "??????";
    }

    public String getThought() {
        return aNiceThought;
    }

    public void setThought(String str) {
        this.aNiceThought = str;
    }
}
