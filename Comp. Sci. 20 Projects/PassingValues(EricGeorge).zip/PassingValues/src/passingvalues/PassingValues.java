/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package passingvalues;

/**
 *
 * @author 1100015542
 */
public class PassingValues {

    /**
     * @param args the command line arguments
     */
    public static double gravy;

    public static void main(String args[]) {
        PassingValues theObj = new PassingValues();
        theObj.gravy = 107.43;
        String s = "hello";
        int xray[] = {1, 2, 3, 4, 5};
        double floozy = 97.4;
        myMethod(floozy, theObj, xray, s );
        System.out.println(floozy);  // Problem 1:
        System.out.println(theObj.gravy);  //Problem 2:  
        System.out.println(xray[2]);  //Problem 3:
        System.out.println(s);  //Problem 4: 
        /* 
        1.  97.4
        2.  10.001
        3.  100
        4. hello
        */
    }

    public static void myMethod(double floozy, PassingValues anObj, int a[], String s) {
        floozy = 13.1;
        anObj.gravy = 10.001;
        a[2] = 100;
        s = "good bye";
    }
}