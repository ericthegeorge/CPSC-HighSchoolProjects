/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gp2stockhistogram;

/**
 *
 * @author 1100015542
 */
import java.util.*;

public class GP2StockHistogram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // AAPL last 100 days adjusted close starting 2013-09-13
        // For this project, following String must be as follows:
        String aaplClosingPriceStr = "464.9 472.69 467.71 494.64 506.17 498.22 "
                + "495.27 498.69 488.58 487.22 491.7 490.9 488.59 502.97 501.02 "
                + "502.96 502.36 501.07 507.74 502.33 497.91 498.5 489.57 467.36 "
                + "454.45 461.01 461.93 462.2 466.37 459.51 453.68 449.56 450.35 "
                + "444.85 438.1 435.62 437.62 416.24 423.51 422.16 428.93 427.49 "
                + "427.38 424.64 423.71 424.49 417.97 419.58 412.33 414.68 418.04 "
                + "415.74 406.54 393.93 391.2 395.46 399.99 399.9 410.79 414.11 "
                + "420.23 428.94 429.17 427.23 433.1 429.36 434.73 436.01 438.91 "
                + "435.58 442.19 446.36 447.76 446.78 448.62 442.03 438.54 442.23 "
                + "439.24 438.46 436.78 440.02 430.42 431.73 426.04 440.95 451.76 "
                + "450 453.77 457.77 452.66 454.68 444.09 439.69 433.54 436.98 "
                + "424.49 411.74 403.03 400.15";
        // Be careful when you copy and paste the above that you don't add extra
        // spaces or delete any spaces between the numbers!
        // ...Your code goes here... // static "helper" method
        String aaplStockDeltasStr = GP2StockHistogram.deltasOfStockPrices(aaplClosingPriceStr);
        double[] aaplStockDeltas = new double[99];
        Scanner ac = new Scanner(aaplStockDeltasStr);
        double bigNum = 0;
        double smallNum = 0;
        int maxIndx = -1;
        while (ac.hasNextDouble()) {
            maxIndx++;
            aaplStockDeltas[maxIndx] = ac.nextDouble();
            if (bigNum <= aaplStockDeltas[maxIndx]) {
                bigNum = aaplStockDeltas[maxIndx];
            }
            if (smallNum >= aaplStockDeltas[maxIndx]) {
                smallNum = aaplStockDeltas[maxIndx];
            }
        }
        ac.close();
        //testing
        //        int count = 0;
        //        for(int i = 0; i <= maxIndx; i++){
        //            count++;
        //            System.out.println(aaplStockDeltas[i] + "\n count: " + count);
        //        }
        //              works
        bigNum = Math.floor(bigNum);
        smallNum = Math.ceil(smallNum);
        int bigNumInt = (int) bigNum;
        bigNumInt++;
        int smallNumInt = (int) smallNum;
        if (smallNumInt < 0) {
            smallNumInt *= -1;
            smallNumInt++;
        }
            //Tested... Issue after this and not due to array assignemnt...
//        for (int i = 0; i <=maxIndx; i++){
//            System.out.println(aaplStockDeltas[i]);
//        }

        //tested... Issue after here and not due to incorrect calcs of array dimensions
        //      System.out.println(" Bignum : " + bigNum + "\n SmallNum :" + smallNum + "\n BignumInt : " + bigNumInt + "\n SmallNumInt: " + smallNumInt);
        
        
        int[] positiveDeltasCount = new int[bigNumInt];
        int[] negativeDeltasCount = new int[smallNumInt];
        Arrays.fill(positiveDeltasCount, 0);
        Arrays.fill(negativeDeltasCount, 0);

        for (int i = 0; i <= maxIndx; i++) {
            if (aaplStockDeltas[i] > 0) {
                int flooredValue = (int) Math.floor(aaplStockDeltas[i]);
                positiveDeltasCount[flooredValue]++;
                //System.out.println(flooredValue);
            }
            if (aaplStockDeltas[i] < 0) {
                int ceiledValue = (int) Math.abs(Math.ceil(aaplStockDeltas[i]));
                negativeDeltasCount[ceiledValue]++;
                //System.out.println(ceiledValue);
            }
        }
        //tested... above works Issue in graphHistogram or barsofNumber...
//        for (int i = 0; i < positiveDeltasCount.length; i++){
//            System.out.println(positiveDeltasCount[i]);
//        }
//                for (int i = 0; i < negativeDeltasCount.length; i++){
//            System.out.println(negativeDeltasCount[i]);
//        }

        String alpha = GP2StockHistogram.graphHistogram(negativeDeltasCount, positiveDeltasCount);
        System.out.println(alpha);
        // tested: issue at array value asssignment...
//        for (int i = 0; i < positiveDeltasCount.length; i++) {
//            System.out.println("Positive delta at " + i + ": " + positiveDeltasCount[i]);
//        }
//        for (int i = 0; i < negativeDeltasCount.length; i++) {
//            System.out.println("Negative delta at " + i + ": " + negativeDeltasCount[i]);
//        }

    }

    public static String graphHistogram(int[] negativeDeltasCount, int[] positiveDeltasCount) {

        String rtnStr = "";
        boolean first = true;
        for (int i = 0; i < positiveDeltasCount.length; i++) {
            int num = positiveDeltasCount[i];
            String thisNumHashes = GP2StockHistogram.barsOfNumber(num);
            if (i < 10 && first == true) {
                rtnStr += "     " + i + ",   " + (i + 1) + ": " + thisNumHashes;
                first = false;
                //System.out.println(rtnStr);
            } else if (i < 10 && (i + 1) < 10) {
                rtnStr += "\n     " + i + ",   " + (i + 1) + ": " + thisNumHashes;
               // System.out.println(rtnStr);
            } else if (i < 10 && (i + 1) >= 10) {
                rtnStr += "\n     " + i + ",  " + (i + 1) + ": " + thisNumHashes;
               // System.out.println(rtnStr);
            } else {
                rtnStr += "\n    " + i + ",  " + (i + 1) + ": " + thisNumHashes;
                //System.out.println(rtnStr);
            }
        }
        for (int i = 0; i < negativeDeltasCount.length; i++) {
            int num = negativeDeltasCount[i];
            String thisNumHashes = GP2StockHistogram.barsOfNumber(num);
            if (i < 10 && (i + 1) < 10) {
                rtnStr = "   - " + (i + 1) + ", - " + i + ": " + thisNumHashes + "\n" + rtnStr;
               // System.out.println(rtnStr);
            } else if (i < 10 && (i + 1) >= 10) {
                rtnStr = "   -" + (i + 1) + ", - " + i + ": " + thisNumHashes + "\n" + rtnStr;
               // System.out.println(rtnStr);
            } else {
                rtnStr = "   -" + (i + 1) + ", -" + i + ": " + thisNumHashes + "\n" + rtnStr;
               // System.out.println(rtnStr);
            }
        }
        return rtnStr;
    }

    // static "helper" method
    public static String barsOfNumber(int num) {
        char hash = '#';
        String rtnHashes = "";
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= num; i++) {
           sb.append(hash);
        }
        rtnHashes =sb.toString();
        return rtnHashes;
    }

    // static "helper" method
    public static String deltasOfStockPrices(String stockPricesStr) {
        Scanner sc = new Scanner(stockPricesStr);
        Double[] deltasAry = new Double[100];
        int maxIndx = -1;
        while (sc.hasNextDouble()) {
            maxIndx++;
            deltasAry[maxIndx] = sc.nextDouble();
        }
        Double[] delta = new Double[maxIndx];
        String deltasStr = "";
        for (int i = 0; i <= maxIndx - 1; i++) {
            delta[i] = (deltasAry[i + 1] - deltasAry[i]);
            deltasStr += delta[i] + " ";
        }
        sc.close();
//        System.out.println(deltasStr);
        return deltasStr;
    }

}
