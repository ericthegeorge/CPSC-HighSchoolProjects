/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computethese;

import java.util.*;
import java.io.*;

/**
 *
 * @author 1100015542
 */
public class ComputeThese {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    }

    public static double absoluteSin(double x) {
        double y = Math.toRadians(x);
        double absSin = Math.abs(Math.sin(y));
        return absSin;
    }

    public static boolean pySinIdChecker(double x, double y) {
        double rhs = Math.sqrt(1 - Math.pow(Math.cos(Math.toRadians(y)), 2));
        boolean tolerable = false;
        if (ComputeThese.withinTolerance(x, rhs, 0.001) == true) {
            tolerable = true;
        }
        return tolerable;
    }

    public static boolean withinTolerance(double x, double y, double t) {
        boolean tolerance = false;
        if (Math.abs(x - y) < Math.abs(t)) {
            tolerance = true;
        }
        return tolerance;
    }
}
