/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package addemup;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;

public class Tester {

    public static void main(String args[]) {
        Scanner kb = new Scanner(System.in);

        System.out.print("Enter something like 8 + 33 + 1,345 -137 : ");
        String s = kb.nextLine(); //Best to store in a String and then create a new Scanner
        //object; otherwise, it can get stuck waiting for input.
        String fixedString1 = s.replace("+", " + ");
        String fixedString2 = fixedString1.replace("-", " - ");
        Scanner sc = new Scanner(fixedString2);
        //Set delimiters to a plus sign surrounded by any amount of white space...or...
        // a minus sign surrounded by any amount of white space.
        //sc.useDelimiter("\\s*\\+\\s*");
        boolean round1 = true;
        String nextSign;
        int nextNumber;
        int sum1 = 0;
        int sum2 = 0;
        while (sc.hasNext()) {
            //if sum is not valued to the first number of s
            if (round1 == true) {
                if (fixedString2.startsWith(" - ")) {
                    sc.skip(" - ");
                    nextNumber = sc.nextInt();
                    sum1 = nextNumber * -1;
                } else {
                    nextNumber = sc.nextInt();
                    sum1 = nextNumber;
                }
                round1 = false;
            } else if (round1 == false) {
                nextSign = sc.next();
                if (nextSign.contains("-")) {
                    nextNumber = sc.nextInt();
                    sum2 = sum2 - nextNumber;
                } else if (nextSign.contains("+")) {
                    nextNumber = sc.nextInt();
                    sum2 = sum2 + nextNumber;
                }
            }
        }
        int totalSum = sum1 + sum2;
        System.out.println("Sum is: " + totalSum);
    }
}
