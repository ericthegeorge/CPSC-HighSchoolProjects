/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package makingtelemetrydata;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;
import java.text.*;

public class MakingTelemetryData {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        Scanner fr = new Scanner(new File("Switches.in.txt"));
        fr.nextLine();
        int maxIndx = -1;
        String[] text = new String[1000];
        while (fr.hasNext()) {
            maxIndx++;
            text[maxIndx] = fr.nextLine();
        }

        //analyzing switches
        for (int i = 0; i <= maxIndx; i++) {
            Scanner nr = new Scanner(text[i]);
            int dataValue = nr.nextInt();
            String sw56 = "";
            String sw57 = "";
            String sw58 = "";
            String sw59 = "";
            String sw60 = "";
            String sw61 = "";
            String sw62 = "";
            String sw63 = "";

            int sw56N = 0;
            int sw57N = 0;
            int sw58N = 0;
            int sw59N = 0;
            int sw60N = 0;
            int sw61N = 0;
            int sw62N = 0;
            int sw63N = 0;

            //56
            sw56N = (dataValue) & (1);
            if (sw56N == 1) {
                sw56 = "\"on\"";
            } else {
                sw56 = "\"off\"";
            }
            //57
            sw57N = (dataValue) & (2);
            if (sw57N == 2) {
                sw57 = "\"on\"";
            } else {
                sw57 = "\"off\"";
            }
            //58
            sw58N = (dataValue) & (4);
            if (sw58N == 4) {
                sw58 = "\"on\"";
            } else {
                sw58 = "\"off\"";
            }
            //59
            sw59N = (dataValue) & (8);
            if (sw59N == 8) {
                sw59 = "\"on\"";
            } else {
                sw59 = "\"off\"";
            }
            //60
            sw60N = (dataValue) & (16);
            if (sw60N == 16) {
                sw60 = "\"on\"";
            } else {
                sw60 = "\"off\"";
            }
            //61
            sw61N = (dataValue) & (32);
            if (sw61N == 32) {
                sw61 = "\"on\"";
            } else {
                sw61 = "\"off\"";
            }
            //62
            sw62N = (dataValue) & (64);
            if (sw62N == 64) {
                sw62 = "\"on\"";
            } else {
                sw62 = "\"off\"";
            }
            //63
            sw63N = (dataValue) & (128);
            if (sw63N == 128) {
                sw63 = "\"on\"";
            } else {
                sw63 = "\"off\"";
            }
            System.out.println("Swtich status for data value " + dataValue + ":");
            System.out.println("  Swtich sw56 is " + sw56);
            System.out.println("  Swtich sw57 is " + sw57);
            System.out.println("  Swtich sw58 is " + sw58);
            System.out.println("  Swtich sw59 is " + sw59);
            System.out.println("  Swtich sw60 is " + sw60);
            System.out.println("  Swtich sw61 is " + sw61);
            System.out.println("  Swtich sw62 is " + sw62);
            System.out.println("  Swtich sw63 is " + sw63);
        }

    }
}
