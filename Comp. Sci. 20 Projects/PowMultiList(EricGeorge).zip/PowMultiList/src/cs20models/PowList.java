/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs20models;

/**
 *
 * @author 1100015542
 */
public class PowList {

    PowPerson[] powList;
    int powCount;

    public PowList() {
        powList = new PowPerson[10000];
        powCount = 0;
    }

    public PowPerson[] toArray() {
        PowPerson[] unbufferedPowList = new PowPerson[powCount];
        for (int i = 0; i < powCount; i++) {
            unbufferedPowList[i] = powList[i];
        }
        return unbufferedPowList;
    }
    
    public void addPow(PowPerson pp) {
        if (powCount >= powList.length) {
            return;
        }
        
        powList[powCount] = pp;
        powCount++;
    }

    public PowPerson getPow(int powSerial) {
        for(int i = 0; i < powCount; i++){
            PowPerson pp = powList [i];
            if (pp.getSerial() == powSerial) {
                return pp;
            }
        }
        return null;
    }

}
