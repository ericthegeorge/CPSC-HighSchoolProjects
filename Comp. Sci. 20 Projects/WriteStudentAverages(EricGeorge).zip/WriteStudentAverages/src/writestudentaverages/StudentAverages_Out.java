/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package writestudentaverages;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;

public class StudentAverages_Out {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        FileWriter fw = new FileWriter("StudentScores.out.txt");
        PrintWriter output = new PrintWriter(fw);
        Scanner fs = new Scanner(new File("StudentScores.in.txt"));
        int maxIndx = -1;
        String[] file = new String[1000];
        while (fs.hasNext()) {
            maxIndx++;
            file[maxIndx] = fs.nextLine();
        }

        String[] names = new String[1000];
        Integer[] avg = new Integer[1000];
        int sum = 0;
        double count = 0.00;
        for (int j = 0; j <= maxIndx; j++) {
            Scanner nr = new Scanner(file[j]);
            names[j] = nr.next();
            while (nr.hasNextInt()) {
                sum += nr.nextInt();
                count++;
            }
            double sumOverNum = Math.round(sum / count);
            avg[j] = (int) sumOverNum;
            output.println(names[j] + ", average = " + avg[j]);
            count = 0;
            sum = 0;
        }
        output.close();
        fw.close();
    }

}
