/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package namethatpersonquizfunction;

/**
 *
 * @author 1100015542
 */
public class NameThatPerson {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    public static String quizThatPersonName (String name) {
        int Strlng = name.length();
        String nameMod = name.substring(3, Strlng - 2);
        return nameMod;
    }
}
