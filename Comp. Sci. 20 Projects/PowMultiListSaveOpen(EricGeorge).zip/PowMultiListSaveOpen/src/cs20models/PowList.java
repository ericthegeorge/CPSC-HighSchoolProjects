/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs20models;

import java.io.*;
import java.util.Scanner;

/**
 *
 * @author 1100015542
 */
public class PowList {

    PowPerson[] powList;
    int powCount;

    public PowList() {
        powList = new PowPerson[10000];
        powCount = 0;
    }

    public PowPerson[] toArray() {
        PowPerson[] unbufferedPowList = new PowPerson[powCount];
        for (int i = 0; i < powCount; i++) {
            unbufferedPowList[i] = powList[i];
        }
        return unbufferedPowList;
    }

    public void addPow(PowPerson pp) {
        if (powCount >= powList.length) {
            return;
        }

        powList[powCount] = pp;
        powCount++;
    }

    public PowPerson getPow(int powSerial) {
        for (int i = 0; i < powCount; i++) {
            PowPerson pp = powList[i];
            if (pp.getSerial() == powSerial) {
                return pp;
            }
        }
        return null;
    }

    public String getSaveString() {
        String saveStr = "";

        for (int i = 0; i < powCount; i++) {
            saveStr = saveStr + powList[i].getSaveString();
            saveStr = saveStr + "\n";
        }
        return saveStr;
    }

    public void saveToFile(String pathToFile) throws IOException {
        FileWriter fw = new FileWriter(pathToFile);
        PrintWriter pw = new PrintWriter(fw);
        String saveStr = this.getSaveString();
        pw.print(saveStr);
        pw.close();
    }

    public void openFromFile(String pathToFile) throws IOException {
        File f = new File(pathToFile);
        Scanner sc = new Scanner(f);

        powList = new PowPerson[10000];
        powCount = 0;

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            String[] fields = (line.split(" "));
                PowPerson pp = new PowPerson();
                pp.setName(fields[0]);
                pp.setRank(fields[1]);
                int serial = Integer.parseInt(fields[2]);
                pp.setSerial(serial);

                this.addPow(pp);
        }
    }

}
