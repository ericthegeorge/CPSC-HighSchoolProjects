/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evenorodd;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*Create a new project called EvenOrOdd containing a class called Tester. In the main method of
Tester print a prompt that says, “Enter an integer:” Input the user’s response from the keyboard,
test the integer to see if it is even or odd (use the modulus operator % to do this), and then print
the result as shown below (several runs are shown).
Enter an integer: 28
The integer 28 is even.
Enter an integer: 2049
The integer 2049 is odd.
Enter an integer: -236
The integer -236 is even. */
        Scanner numberReader = new Scanner(System.in);
        System.out.println("Enter an integer: ");
        int integerInput = numberReader.nextInt();
        double remainder = integerInput%2;
        if (remainder == 0) 
            System.out.print("The intger " + integerInput + " is even.");
        else
            System.out.print("The intger " + integerInput + " is odd.");
    }
    
}
