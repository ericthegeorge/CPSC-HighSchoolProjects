/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package namereverserupper;

/**
 *
 * @author 1100015542
 */
public class NameReverserUpper {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
 
    }

    public static String nameReverseUpper(String s) {
        s = s.toUpperCase();
        int length = s.length();
        String rtnStr = "";
        for (int i = 1; i <= length; i++) {
            char ch = s.charAt(length - i);
            rtnStr = rtnStr + ch;
        }
        return rtnStr;
    }

}
