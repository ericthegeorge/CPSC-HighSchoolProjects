/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamecharacterict;

/**
 *
 * @author 1100015542
 */
public class GameCharacter {
    public String name;
    public int power;
    public int health;
    
    public GameCharacter(String name, int power){
        this.name = name;
        this.power = power;
        this.health = 0;
    }
    
    public void increaseHealth (int amount){
        this.health += amount;
    }
    
    public void lowerHealth (int amount) {
        this.health -= amount;
    }
}
