/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mymagpielabproject;

/**
 *
 * @author 1100015542
 */
public class StringExplorer {

    /**
     * @param args the command line arguments
     */
 public static void main(String[] args)
	{
//		String sample = "The quick brown fox jumped over the lazy dog.";
//		
//		//  Demonstrate the indexOf method.
//		int position = sample.indexOf("quick");
//		System.out.println ("sample.indexOf(\"quick\") = " + position);
//		
//		//  Demonstrate the toLowerCase method.
//		String lowerCase = sample.toLowerCase();
//		System.out.println ("sample.toLowerCase() = " + lowerCase);
//		System.out.println ("After toLowerCase(), sample = " + sample);
//		
//		//  Try other methods here:
            String s = "Four score and seven years ago.";
            System.out.print("Question 1: ");
                System.out.println(s.substring(3));
                
            System.out.print("Question 2: ");
                System.out.println(s.substring(5,12));
                
            System.out.print("Question 3: ");
                System.out.println(s.toLowerCase());
                
            System.out.print("Question 4: ");
                System.out.println(s.indexOf("score"));
                
            System.out.print("Question 5: ");
                System.out.println(s.substring(2, s.length() - 5));
                
            System.out.print("Question 6: ");
                s = "   " + s + "hello   ";
                s = s.trim();
                System.out.println(s.indexOf("and"));
                
            System.out.print("Question 7: ");
                s = "Four score and seven years ago.";
                System.out.println(s.indexOf("seveny"));
	}
    
}
