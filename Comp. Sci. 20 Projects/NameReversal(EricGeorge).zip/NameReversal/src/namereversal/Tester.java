/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package namereversal;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;

public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Please enter your name. ");
        Scanner nameReader = new Scanner(System.in);
        String original = nameReader.nextLine();
        String originalName = original.toLowerCase();
        int length = originalName.length();
        for (int j = length - 1; j >= 0; j--) {
            char letter = originalName.charAt(j);
            System.out.print(letter);
        }

    }

}
