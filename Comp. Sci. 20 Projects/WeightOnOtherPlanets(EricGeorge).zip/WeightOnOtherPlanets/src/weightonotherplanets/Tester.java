/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weightonotherplanets;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;

public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*Write a program that will determine the user’s weight on another planet. The program should
ask the user to enter his weight (on earth) via the keyboard and then present a menu of the
other mythical planets. The user should choose one of the planets from the menu, and use a
switch (with an integer) statement to calculate the weight on the chosen planet. Use the
following conversion factors to determine the user’s weight on the chosen planet.
Planet Multiply weight by
Voltar 0.091
Krypton 0.720
Fertos 0.865
Servontos 4.612
A typical output screen will be similar to the following:
What is your weight on the Earth? 135

1. Voltar
2. Krypton
3. Fertos
4. Servontos
 Selection? 1
Your weight on Voltar would be 12.285 */
        System.out.println("What is your weight on the Earth? ");
        Scanner weightReader = new Scanner(System.in);
        double earthWeight = weightReader.nextInt();
        System.out.println("1. Voltar\n"
                + "2. Krypton\n"
                + "3. Fertos\n"
                + "4. Servontos");
        System.out.println("Selection?");
        int choice = weightReader.nextInt();
        double voltarWeight = earthWeight * 0.091;
        double kryptonWeight = earthWeight * 0.720;
        double fertosWeight = earthWeight * 0.865;
        double servontosWeight = earthWeight * 4.612;
        switch (choice) {
            case 1:
                System.out.println("Your weight on Voltar would be " + voltarWeight);
                break;
            case 2:
                System.out.println("Your weight on Krypton would be " + kryptonWeight);
                break;
            case 3:
                System.out.println("Your weight on Fertos would be " + fertosWeight);
                break;
            case 4:
                System.out.println("Your weight on Servontos would be " + servontosWeight);
                break;

        }
    }

}
