/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrixstuff;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][] a = { {1, 2, -2, 0}, {-3, 4, 7, 2}, {6, 0, 3, 1} };
        int[][]b = { {-1, 3}, {0, 9}, {1, -11}, {4, -5} };
        int[][] productAry = MatrixMult.mult(a, b);
        String productStr = "";
        for (int i = 0; i < productAry.length; i++){
            for (int k = 0; k < productAry[0].length; k++){
                if (k != 1){
                    productStr += "\t" + productAry[i][k] + "\t" + productAry[i][k+1] + "\n";
                }
            }
        }
        System.out.println(productStr);
    }  
}
