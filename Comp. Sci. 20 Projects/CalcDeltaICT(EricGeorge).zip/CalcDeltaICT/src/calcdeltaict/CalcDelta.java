/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calcdeltaict;

/**
 *
 * @author 1100015542
 */
public class CalcDelta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double[] anAry = new double[100];
        double[] anotherAry = new double[50];
        for (int i = 0; i < anAry.length; i++) {
            anAry[i] = i;
        }

        for (int i = 0; i < anotherAry.length; i++) {
            anotherAry[i] = i * 2;
        }
        
        
//        System.out.println("originals:");
//        for (int i = 0; i < anAry.length; i++){
//            System.out.println("AnAry:" + anAry[i]);
//        }
//        for (int i = 0; i < anotherAry.length; i++){
//            System.out.println("AnotherAry:" + anotherAry[i]);
//        }        
//        
//        System.out.println(CalcDelta.deltas(anAry));
//        System.out.println(CalcDelta.deltas(anotherAry));
//        
//                System.out.println("new but should be the same:");
//        for (int i = 0; i < anAry.length; i++){
//            System.out.println("AnAry:" + anAry[i]);
//        }
//        for (int i = 0; i < anotherAry.length; i++){
//            System.out.println("AnotherAry:" + anotherAry[i]);
//        }  

        double[] receivedAnAry = CalcDelta.deltas(anAry);
        double [] receivedAnotherAry = CalcDelta.deltas(anotherAry);
        for (int i = 0; i < receivedAnAry.length; i++){
            System.out.println("anAryR" + receivedAnAry[i]);
        }
        
        for (int i = 0; i < receivedAnotherAry.length; i++) {
            System.out.println("anotherAryR" + receivedAnotherAry[i]);
        }
        
                for (int i = 0; i < anotherAry.length; i++) {
            System.out.println("anotherAry....." + anotherAry[i]);
        }
        
        
    }

    public static double[] deltas(double[] doubAry) {
        double[] deltaAry = new double[doubAry.length - 1];
        for (int i = 0; i < deltaAry.length; i++) {
            double aDelta = doubAry[i + 1] - doubAry[i];
            System.out.println("Delta: " + aDelta);
            deltaAry[i] = aDelta;
        }
        return deltaAry;
    }
}
