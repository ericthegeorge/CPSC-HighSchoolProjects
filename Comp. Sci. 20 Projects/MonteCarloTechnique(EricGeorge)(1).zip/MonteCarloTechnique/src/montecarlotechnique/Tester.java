/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package montecarlotechnique;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MonteCarlo mcObj = new MonteCarlo(5, 3, 2);
        int cirCount = 0;
        int sqrCount = 0;
        for (double i = 1; i <= 1000000; i++){
            double raindropX = mcObj.nextRainDrop_x();
            double raindropY = mcObj.nextRainDrop_y();
            boolean inCircle = mcObj.insideCircle(raindropX, raindropY);
            if (inCircle == true){
                cirCount++;
            }
            sqrCount++;
        }
        double count = sqrCount / cirCount;
        double areaRatio = Math.pow(MonteCarlo.r * 2, 2)/ (Math.PI * Math.pow(MonteCarlo.r, 2));
        double ourPI = count / areaRatio;
        System.out.println(ourPI);

    }
    
}
