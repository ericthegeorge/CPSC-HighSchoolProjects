/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package montecarlotechnique;

import java.util.Random;

/**
 *
 * @author 1100015542
 */
public class MonteCarlo {

    public static double h;
    public static double k;
    public static double r;

    public MonteCarlo(double h, double k, double r) {
        this.h = h;
        this.k = k;
        this.r = r;
    }

    private Random rndm = new Random();

    public double nextRainDrop_x() {
        double xLength = h * 2;
        double theNextDropX = rndm.nextDouble() * xLength;
        return theNextDropX;
    }

    public double nextRainDrop_y() {
        double yLength = k * 2;
        double theNextDropY = rndm.nextDouble() * yLength;
        return theNextDropY;
    }

    public boolean insideCircle(double x, double y) {
        boolean inside = false;
        if ((Math.pow(x - h, 2) + Math.pow(y - k, 2)) <= Math.pow(r, 2)) {
            inside = true;
        }
        return inside;
    }

}
