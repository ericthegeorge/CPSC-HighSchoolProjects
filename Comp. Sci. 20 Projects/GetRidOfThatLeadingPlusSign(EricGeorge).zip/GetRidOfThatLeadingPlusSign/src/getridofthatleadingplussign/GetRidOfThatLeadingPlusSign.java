/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package getridofthatleadingplussign;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;

public class GetRidOfThatLeadingPlusSign {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        Scanner fr = new Scanner(new File("NumData.in.txt"));
        int maxIndx = -1; //-1 so when we increment below, the first index is 0
        String text[] = new String[1000]; //To be safe, declare more than we need
        while (fr.hasNext()) {
            maxIndx++;
            text[maxIndx] = fr.nextLine();
            //System.out.println(text[maxIndx]); //Remove rem for testing
        }
//maxIndx is now the highest index of text[], -1 if no text lines
        fr.close(); //We opened a file above, so close it when finished.

        String answer = null; //We will accumulate the answer string here.
        int sum; //accumulates sum of integers
        for (int j = 0; j <= maxIndx; j++) {
            Scanner sc = new Scanner(text[j]);
            sum = 0; //important to set to 0; otherwise it will remember the last sum
            answer = "~"; //otherwise it will remember last answer String
            while (sc.hasNext()) { //We could also have used hasNextInt( ) here
                int i = sc.nextInt();
                if (answer.contains("~")){
                    answer = i + "";
                }else {
                answer = answer + " + " + i;
                sum = sum + i;
                }
            }
            answer = answer + " = " + sum;
            System.out.println(answer);
        }
    }
}
