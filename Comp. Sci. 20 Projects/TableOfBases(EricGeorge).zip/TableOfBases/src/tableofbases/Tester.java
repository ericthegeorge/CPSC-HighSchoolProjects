/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableofbases;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*Create a project called TableOfBases with class Tester. The main method should have a for loop
        that cycles through the integer values 65 <= j <= 90 (These are the ASCII codes for characters A
        – Z). Use the methods learned in this lesson to produce a line of this table on each pass through
        the loop. Display the equivalent of the decimal number in the various bases just learned (binary,
        octal, and hex) as well as the character itself:
        Decimal Binary Octal Hex Character
        65 1000001 101 41 A
        66 1000010 102 42 B
        67 1000011 103 43 C
        68 1000100 104 44 D
        69 1000101 105 45 E
        70 1000110 106 46 F
        71 1000111 107 47 G
        72 1001000 110 48 H
        73 1001001 111 49 I
        74 1001010 112 4a J
        75 1001011 113 4b K
        76 1001100 114 4c L
        77 1001101 115 4d M
        78 1001110 116 4e N
        79 1001111 117 4f O
        80 1010000 120 50 P
        81 1010001 121 51 Q
        82 1010010 122 52 R
        83 1010011 123 53 S
        84 1010100 124 54 T
        85 1010101 125 55 U
        86 1010110 126 56 V
        87 1010111 127 57 W
        88 1011000 130 58 X
        89 1011001 131 59 Y
        90 1011010 132 5a Z*/
        System.out.println("Decimal     Binary          Octal       Hex         Character");
        int j;
        String space1 = "          ";
        String space2 = "         ";
        String space3 = "         ";
        String space4 = "          ";
        for (j = 65; 65 <= j && j <= 90; j++) {
                    char character = (char)j;
            System.out.print(j + space1);
            System.out.print(Integer.toString(j, 2) + space2);
            System.out.print(Integer.toString(j, 8) + space3);
            System.out.print(Integer.toString(j, 16) + space4);
            System.out.println(character);
        }
    }
}
