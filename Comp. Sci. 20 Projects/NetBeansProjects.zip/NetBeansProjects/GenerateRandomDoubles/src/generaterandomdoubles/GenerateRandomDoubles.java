/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generaterandomdoubles;

/**
 *
 * @author 1100015542
 */
import java.util.Random;

public class GenerateRandomDoubles {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double dif = 147.22 - 99.78;
        Random rndm = new Random();
        for (int i = 1; i <= 27; i++) {
            double x = rndm.nextDouble() * dif + 99.78;
            System.out.println(x);
        }
    }
    
}
