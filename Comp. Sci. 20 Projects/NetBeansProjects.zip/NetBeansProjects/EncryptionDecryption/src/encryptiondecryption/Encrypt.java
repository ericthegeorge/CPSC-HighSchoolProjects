/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encryptiondecryption;

/**
 *
 * @author 1100015542
 */
public class Encrypt {

    public String acceptedStringE;

    public Encrypt(String s) {
        acceptedStringE = s;
    }

    public String Encrypter() {
        String encryptedA = acceptedStringE.replace("G", "0");
        String encryptedB = encryptedA.replace("g", "1");
        String encryptedC = encryptedB.replace("V", "2");
        String encryptedD = encryptedC.replace("v", "3");
        String encryptedE = encryptedD.replace("M", "4");
        String encryptedF = encryptedE.replace("m", "5");
        String encryptedG = encryptedF.replace("B", "6");
        String encryptedH = encryptedG.replace("b", "7");

        String encrypted1 = encryptedH.replace("0", "jeb..w");
        String encrypted2 = encrypted1.replace("1", "jeb..w");
        String encrypted3 = encrypted2.replace("2", "ag’,r");
        String encrypted4 = encrypted3.replace("3", "ag’,r");
        String encrypted5 = encrypted4.replace("4", "ssad");
        String encrypted6 = encrypted5.replace("5", "ssad");
        String encrypted7 = encrypted6.replace("6", "dug>?/");
        String encrypted8 = encrypted7.replace("7", "dug>?/");
        return encrypted8;
    }

}
