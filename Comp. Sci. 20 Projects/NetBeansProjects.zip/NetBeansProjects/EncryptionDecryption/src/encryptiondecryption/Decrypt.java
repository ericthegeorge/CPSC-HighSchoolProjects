/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encryptiondecryption;

/**
 *
 * @author 1100015542
 */
public class Decrypt {

    public String acceptedStringD;

    public Decrypt(String s) {
        acceptedStringD = s;
    }

    public String Decrypter() {
        String decrypted8 = acceptedStringD.replace("dug>?/", "b");
        String decrypted7 = decrypted8.replace("dug>?/", "B");
        String decrypted6 = decrypted7.replace("jeb..w", "g");
        String decrypted5 = decrypted6.replace("jeb..w", "G");
        String decrypted4 = decrypted5.replace("ssad", "m");
        String decrypted3 = decrypted4.replace("ssad", "M");
        String decrypted2 = decrypted3.replace("ag’,r", "v");
        String decrypted1 = decrypted2.replace("ag’,r", "V");
        return decrypted1;
    }

}
