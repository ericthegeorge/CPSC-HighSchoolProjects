/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tester;

/**
 *
 * @author 1100015542
 */
public class NameThatCelebrity {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println(79 + 3 * (4 + 82 - 68) - 7 + 19);
         
        System.out.println(f);
        
        System.out.print(d);
    }
    
}
