/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package disttoline;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Here is how things will be organized in the class:
//• Call the class DistToLine.
//• Create static double state variables A, B, and C.
//• Create the signature of the static method getDist. It will receive doubles a and b. It will
//return a double representing the calculated distance.
//• In the body of this method, implement the distance formula above and return that value.
//Create a Tester class as part of this project that will:
//• Set the static state variables A, B, and C with the corresponding values of the desired line
//entered from the keyboard.
//• Call the method getDist and pass as arguments the coordinates of the desired point
//entered from the keyboard.
//• Print the returned double as the distance from the point to the line.
//Typical output of the Tester class is shown below:
//Enter the A value for the line: 2.45
//Enter the B value for the line: 4
//Enter the C value for the line: -8
//Enter the x coordinate of the point: 2.17
//Enter the y coordinate of the point: -4
//Distance from the point to the line is: 3.9831092774319026 
        System.out.print("Enter the A value for the line: ");
        Scanner valueReader = new Scanner(System.in);
        DistToLine.A = valueReader.nextDouble();
        System.out.print("Enter the B value for the line: ");
        DistToLine.B = valueReader.nextDouble();
        System.out.print("Enter the C value for the line: ");
        DistToLine.C = valueReader.nextDouble();
        System.out.print("Enter the x coordinate of the point: ");
        double xCoord = valueReader.nextDouble();
        System.out.print("Enter the y coordinate of the point: ");
        double yCoord = valueReader.nextDouble();
        System.out.print("Distance from the point to the line is: " + DistToLine.getDist(xCoord, yCoord));
    }
    
}
