/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package disttoline;

/**
 *
 * @author 1100015542
 */
public class DistToLine {

    public static double A;
    public static double B;
    public static double C;

    public static double getDist(double a, double b) {
        double calculatedDistance1 = (A * a) + (B * b) + C;
        double calculatedDistance2 = Math.abs(calculatedDistance1);
        double calculatedDistance3 = Math.pow(A, 2) + Math.pow(B, 2);
        double calculatedDistance4 = Math.sqrt(calculatedDistance3);
        double calculatedDistance5 = calculatedDistance2 / calculatedDistance4;
        return calculatedDistance5; 
    }
}
