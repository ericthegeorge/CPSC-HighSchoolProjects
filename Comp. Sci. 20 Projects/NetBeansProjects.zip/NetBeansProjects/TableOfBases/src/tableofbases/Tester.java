/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableofbases;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Decimal     Binary          Octal       Hex         Character");
        int j;
        String space1 = "          ";
        String space2 = "         ";
        String space3 = "         ";
        String space4 = "          ";
        for (j = 65; 65 <= j && j <= 90; j++) {
                    char character = (char)j;
            System.out.print(j + space1);
            System.out.print(Integer.toString(j, 2) + space2);
            System.out.print(Integer.toString(j, 8) + space3);
            System.out.print(Integer.toString(j, 16) + space4);
            System.out.println(character);
        }
    }
}
