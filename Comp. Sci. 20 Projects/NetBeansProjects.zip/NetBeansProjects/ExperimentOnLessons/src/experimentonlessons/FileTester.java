/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package experimentonlessons;

/**
 *
 * @author 1100015542
 */
import java.io.*; // necessary for File and IOException
import java.util.*; // necessary for Scanner

public class FileTester {

    public static void main(String args[]) throws IOException {
        int m = 45;
        int p = 4;
        int k = 102;
        System.out.println(m << 2); 
    }
}
