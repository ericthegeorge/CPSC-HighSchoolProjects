/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankaccount;

/**
 *
 * @author 1100015542
 */
public class BankAccount {
    public double balance;
    public String name;
    public BankAccount(double balance, String name){
        this.balance = balance;
        this.name = name;
    }
    public void deposit(double deposital){
        balance += deposital;
    }
    public void withdraw(double withdrawal){
        balance-= withdrawal;
    }
}
