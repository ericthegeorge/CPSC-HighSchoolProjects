/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankaccount;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String name1 = "Homer";
        String name2 = "Marge";
        String name3 = "Simpson";
        BankAccount homer = new BankAccount(100, name1);
        BankAccount marge = new BankAccount(100, name2);
        BankAccount simpson = new BankAccount(100, name3);
        homer.deposit(10);
        marge.deposit(10);
        simpson.deposit(10);
        homer.withdraw(9);
        marge.withdraw(8);
        simpson.withdraw(7);
        System.out.println(homer.balance);
        System.out.println(marge.balance);
        System.out.println(simpson.balance);
        
    }
    
}
