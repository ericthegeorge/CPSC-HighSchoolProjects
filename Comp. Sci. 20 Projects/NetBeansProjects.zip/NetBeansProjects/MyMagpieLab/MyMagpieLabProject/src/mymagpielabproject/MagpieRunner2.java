/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mymagpielabproject;

/**
 *
 * @author 1100015542
 */
import java.util.*;
public class MagpieRunner2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /**
	 * Create a Magpie, give it user input, and print its replies.
	 */
		Magpie2 maggie = new Magpie2();
		
		System.out.println (maggie.getGreeting());
		Scanner in = new Scanner (System.in);
		String statement = in.nextLine();
		
		while (!statement.equals("Bye")){
			System.out.println (maggie.getResponse(statement));
			statement = in.nextLine();
		}

    }
    
}
