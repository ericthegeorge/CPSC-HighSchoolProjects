/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package divisiblebywhatict2;

/**
 *
 * @author 1100015542
 */
public class DivisibleByWhat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int aNum = 1000000000;
        int[] anArr = DivisibleByWhat.divisorsOf(aNum);
        for (int i = 0; i < anArr.length; i++) {
            System.out.println(anArr[i]);
        }
        
    }
    
    public static boolean isDivisibleBy(int x, int d) {
        return (x % d == 0);
    }
    
    public static int[] divisorsOf (int x) {
        int[] buffer = new int[(int) Math.sqrt(x)];
        int[] bufferB = new int [(int) Math.sqrt(x)];
        int divisorsNum = 0;
        int codivisorsNum = 0;
        for (int i = 1; i <= Math.sqrt(x); i++){
            if (DivisibleByWhat.isDivisibleBy(x, i) == true){
                buffer[divisorsNum] = i;
                divisorsNum++;
                int codivisor = x/i;
                if (codivisor != i) {
                    bufferB[codivisorsNum] = codivisor;
                    codivisorsNum++;
                }
            }
        }
        
        int[] divisorsArr = new int[divisorsNum + codivisorsNum];
        for (int i = 0; i < divisorsNum; i++) {
            divisorsArr[i] = buffer[i];
        }
        for (int i = 0; i < codivisorsNum; i++) {
            divisorsArr[divisorsNum + i] = bufferB[codivisorsNum - i - 1];
            //System.out.println("codivisor at " + i + " is " + bufferB[codivisorsNum - i - 1]);
        }
        
        for (int i = 0; i < codivisorsNum; i++) {
            //System.out.println(bufferB[i]);
        }
        return divisorsArr;
        
    }
    
}
