/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mymagpielabday3;

/**
 *
 * @author 1100015542
 */
import java.util.*;
public class MagpieRunner3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Magpie3 maggie = new Magpie3();
		
		System.out.println (maggie.getGreeting());
		Scanner in = new Scanner (System.in);
		String statement = in.nextLine();
		
		while (!statement.equals("Bye")){
			System.out.println (maggie.getResponse(statement));
			statement = in.nextLine();
		}
    }
    
}
