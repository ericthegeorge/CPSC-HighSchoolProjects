/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamecharacterict;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GameCharacter Link = new GameCharacter("Link", 1000);
        GameCharacter Lara = new GameCharacter("Lara", 10000);
        GameCharacter Test = new GameCharacter("Test", 10);
//increase
        Link.increaseHealth(250);
        System.out.println(Link.health);
        System.out.println(Lara.health);
        System.out.println(Test.health);
        Lara.increaseHealth(500);
        System.out.println(Link.health);
        System.out.println(Lara.health);
        System.out.println(Test.health);
        Test.increaseHealth(10);
        System.out.println(Link.health);
        System.out.println(Lara.health);
        System.out.println(Test.health);
//decrease
        Link.lowerHealth(250);
        System.out.println(Link.health);
        System.out.println(Lara.health);
        System.out.println(Test.health);
        Lara.lowerHealth(500);
        System.out.println(Link.health);
        System.out.println(Lara.health);
        System.out.println(Test.health);
        Test.lowerHealth(10);
        System.out.println(Link.health);
        System.out.println(Lara.health);
        System.out.println(Test.health);
        //correct

    }

}
