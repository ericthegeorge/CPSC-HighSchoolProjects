/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayofhope;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        char ch[] = new char[26];
        for (int i = 65; i <= 90; i++) {
            char character = (char) i;
            ch[i - 65] = character;
        }
        for (int i = 0; i < 26; i++) {
            System.out.print(ch[i]);
            if (i < 25) {
                System.out.print(", "); 
            }
        }
    }

}
