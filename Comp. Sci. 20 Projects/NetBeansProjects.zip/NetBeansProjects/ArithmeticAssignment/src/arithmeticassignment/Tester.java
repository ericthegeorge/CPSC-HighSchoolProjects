/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arithmeticassignment;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String problem1 = "79 + 3 * (4 + 82 - 68) - 7 + 19 = ";
        String problem2 = "(179 + 21 + 10) / 7 + 181 = ";
        String problem3 = "10389 * 56 * 11 + 2246 = ";

        int solve1 = 79 + 3 * (4 + 82 - 68) - 7 + 19;
        int solve2 = (179 + 21 + 10) / 7 + 181;
        int solve3 = 10389 * 56 * 11 + 2246;

        System.out.println(problem1 + solve1);
        System.out.println(problem2 + solve2);
        System.out.println(problem3 + solve3);

    }

}
