/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package firstpracticebpj1.pkg2desc;

/**
 *
 * @author 1100015542
 */
public class FirstPractice12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    public static void first(String str) {
        System.out.println(str + str + str);
    }
    public static int practice(int num) {
        int solved = num + 3;
        return solved;
    }
    
}
