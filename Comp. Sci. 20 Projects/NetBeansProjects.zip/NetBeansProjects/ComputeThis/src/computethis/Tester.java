/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computethis;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //d1
        final double pi = Math.PI;
        final double threePi = 3 * pi;
        final double sin187 = Math.sin(Math.toRadians(187));
        final double cos122 = Math.cos(Math.toRadians(122));
        double part1 = threePi * sin187;
        double part2 = Math.abs(cos122);
        final double d1 = part1 + part2;
        System.out.println("d1 " + "= " + d1);

        //d2
        final double num = 14.72;
        final double exp = 3.801;
        final double power = Math.pow(num, exp);
        final double naturalLog = Math.log(72);
        double d2 = power + naturalLog;
        System.out.println("d2 " + "= " + d2);
    }

}
