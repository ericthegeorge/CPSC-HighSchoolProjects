/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javazetcodeswingtimerattempt1;

/**
 *
 * @author 1100015542
 */

import java.awt.Image;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;


public class SpaceShip {
    
}
