/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matrixstuff;

/**
 *
 * @author 1100015542
 */
import java.util.Arrays;
import java.util.Scanner;

public class MatrixMult {

    public static int[][] mult(int[][] a, int[][] b) {
        int rowNum = a.length;
        int coloumnNum = b[0].length;
        int[][] productAry = new int[rowNum][coloumnNum];
        for (int i = 0; i < rowNum; i++) {
            Arrays.fill(productAry[i], 1);
        }

        int aryARL = a.length;
        int aryBRL = b.length;
        int aryACL = a[0].length;
        int aryBCL = b[0].length;
//        String aryAStr = "";
//        String aryBStr = "";
//        for (int i = 1; i <= aryARL; i++) {
//            for (int j = 1; j <= aryACL; j++) {
//                System.out.println(a[i - 1][j - 1]);
//                aryAStr = aryAStr + a[i - 1][j - 1] + " + ";
//            }
//        }
//        for (int i = 1; i <= aryBRL; i++) {
//            for (int j = 1; j <= aryBCL; j++){
//                System.out.println(b[i - 1][j - 1]);
//                aryBStr = aryBStr + b[i - 1][j - 1] + " + ";
//
//            }
//        }
//        
//        
//                                                                              //TESTING
//        System.out.println(aryAStr);
//        System.out.println(aryBStr);
//        aryAStr.replace("s*\\+\\s*", " ");
//        aryBStr.replace("s*\\+\\s*", " ");
//        
//        Scanner arA = new Scanner(aryAStr);
//        Scanner arB = new Scanner(aryBStr);
//                                                                           //TESTING
//        int sum = 0;
        //did not work/too messy
//        for (int t = 1; t <= aryBCL; t++){
//        for (int i = 1; i <= aryARL; i++) {
//            for (int j = 1; j <= aryARL; j++) {
//                sum = 0;
//                for (int k = 1; k <= aryACL; k++) {
//                    sum += a[j - 1][k - 1] * b[t - 1][i - 1];
//
//                }
//                System.out.println(sum);
//            }
//        }
//        }
//                                                                            //TESTING
        int sum = 0;
        for (int i = 0; i < aryBCL; i++) {
            for (int k = 0; k < aryARL; k++) {
                for (int t = 0; t < aryACL; t++) {
                    sum += a[k][t] * b[t][i];
                }
                productAry[k][i] = sum;
                sum = 0;
            }
        }

//return Array
        return productAry;
    }
}
