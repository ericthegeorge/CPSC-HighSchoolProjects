/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package overdrawnatthebank;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner moneyReader = new Scanner(System.in);
        System.out.println("Enter the amount of money initially to be put into the account " +
"along with the name of the person to whom the account belongs. ");
        double initial = moneyReader.nextDouble();
        String firstName = moneyReader.next();
        String lastName = moneyReader.next();
        String fullName = firstName + " " + lastName;
        BankAccount myAccount = new BankAccount(initial, fullName);
        myAccount.deposit(505.22);
        System.out.println(myAccount.balance);
        myAccount.withdraw(100);
        System.out.println("The " + fullName + " acount balance is, $" + myAccount.balance);
    }
    
}
