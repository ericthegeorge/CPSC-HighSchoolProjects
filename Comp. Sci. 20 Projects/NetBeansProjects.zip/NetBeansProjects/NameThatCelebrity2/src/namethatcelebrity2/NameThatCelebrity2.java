/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package namethatcelebrity2;

/**
 *
 * @author 1100015542
 */
public class NameThatCelebrity2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    }
    public static String quiz(String s){
        int leng = s.length();
        String quizString = s + ">>>" + s.substring(2, leng - 3);
        return quizString;
    }
}
