/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generaterandomintegers;

/**
 *
 * @author 1100015542
 */
import java.util.Random;

public class GenerateRandomIntegers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for (int i = 1; i <= 33; i++) {
            Random rndm = new Random();
            int x = rndm.nextInt(29) + 71;
            System.out.println(x);
        }
    }

}
