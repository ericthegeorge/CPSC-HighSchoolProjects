/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fullname;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;
public class FullName {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*From the keyboard enter your first and then your last name, each with its own prompt.
Store each in a separate String and then concatenate them together to show your full
name. Call both the project and the class FullName. When your program is finished
running, the output should appear similar to that below:
 What is your first name? Cosmo
 What is your last name? Kramer
 Your full name is Cosmo Kramer.*/
        Scanner nameReader = new Scanner(System.in);
        System.out.println("What is your first name? ");
        String firstName = nameReader.next();
        System.out.println("What is your last name? ");
        String lastName = nameReader.next();
        String fullName = firstName + (" ") + lastName;
        System.out.println("Your full name is " + fullName + ("."));
        
        
        
    }
    
}
