/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calcdeltaict;

/**
 *
 * @author 1100015542
 */
public class CalcDelta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }

    public static double[] deltas(double[] doubAry) {
        double[] deltaAry = new double[doubAry.length - 1];
        for (int i = 0; i < deltaAry.length; i++) {
            double aDelta = doubAry[i + 1] - doubAry[i];
            System.out.println("Delta: " + aDelta);
            deltaAry[i] = aDelta;
        }
        return deltaAry;
    }
}
