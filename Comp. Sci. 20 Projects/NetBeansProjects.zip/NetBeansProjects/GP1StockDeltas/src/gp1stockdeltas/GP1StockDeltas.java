/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gp1stockdeltas;

/**
 *
 * @author 1100015542
 */
import java.util.Scanner;
public class GP1StockDeltas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // AAPL last 100 days adjusted close starting 2013-09-13
        // For this project, following String must be as follows:
        String aaplClosingPriceStr = "464.9 472.69 467.71 494.64 506.17 498.22 "
                + "495.27 498.69 488.58 487.22 491.7 490.9 488.59 502.97 501.02 "
                + "502.96 502.36 501.07 507.74 502.33 497.91 498.5 489.57 467.36 "
                + "454.45 461.01 461.93 462.2 466.37 459.51 453.68 449.56 450.35 "
                + "444.85 438.1 435.62 437.62 416.24 423.51 422.16 428.93 427.49 "
                + "427.38 424.64 423.71 424.49 417.97 419.58 412.33 414.68 418.04 "
                + "415.74 406.54 393.93 391.2 395.46 399.99 399.9 410.79 414.11 "
                + "420.23 428.94 429.17 427.23 433.1 429.36 434.73 436.01 438.91 "
                + "435.58 442.19 446.36 447.76 446.78 448.62 442.03 438.54 442.23 "
                + "439.24 438.46 436.78 440.02 430.42 431.73 426.04 440.95 451.76 "
                + "450 453.77 457.77 452.66 454.68 444.09 439.69 433.54 436.98 "
                + "424.49 411.74 403.03 400.15";
        // Be careful when you copy and paste the above that you don't add extra
        // spaces or delete any spaces between the numbers!
        // ...Your code goes here...
        double[] aaplClosingPriceAry = new double [100];
        Scanner sc = new Scanner(aaplClosingPriceStr);
        int maxIndx = -1;
        while(sc.hasNextDouble()) {
            maxIndx++;
            aaplClosingPriceAry[maxIndx] = sc.nextDouble();
        }
        Double[] delta = new Double [maxIndx];
        
        for (int i = 0; i <= maxIndx - 1; i++){
            delta[i] = aaplClosingPriceAry[i + 1] - aaplClosingPriceAry[i];
        }
        
        String deltaStr = "";
        for (int i = 0; i <= maxIndx - 1; i++){
                deltaStr += delta[i] + " ";
        }
        System.out.println(deltaStr);

        
    }

}
