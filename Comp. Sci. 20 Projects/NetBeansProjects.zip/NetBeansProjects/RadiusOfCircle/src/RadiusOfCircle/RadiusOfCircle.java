/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RadiusOfCircle;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;

public class RadiusOfCircle {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*The area of a circle is given by:
 area = π (r2
)
Now, suppose we know the area and wish to find r. Solving for r from this equation
yields:
Write a program (project and class both named RadiusOfCircle) that uses sqrt( ) and PI
from the Math class to solve for the radius of a circle. Use keyboard input to specify the
area (provide for the possibility of area being a decimal fraction).
Write out your solution by hand and then enter it into the computer and run. Before
inputting the area, put a prompt on the screen like this.
 What is the area? _ …(the underscore indicates the cursor waiting for input)
 Present your answer like this:
Radius of your circle is 139.4. */
        final double pi = Math.PI;
        Scanner areaReader = new Scanner(System.in);
        System.out.println("What is the area? ");
        double area = areaReader.nextDouble();
        double aOverPi = area / pi;
        double radius = Math.sqrt(aOverPi);
        System.out.printf("Radius of your circle is %.1f.%n", radius);
       
    }

}
