/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gasmileage;

/**
 *
 * @author 1100015542
 */
public class Automobile {
    public double gallons;
    public double mpg;
    public Automobile(double gasMileage) {
        mpg = gasMileage;
        gallons = 0;
    }
    public void fillUp(double f) {
        gallons += f;
    }
    public void takeTrip(double miles){
        gallons -= (miles/ mpg);
    }
    public double reportFuel(){
        return gallons;
    }
}
