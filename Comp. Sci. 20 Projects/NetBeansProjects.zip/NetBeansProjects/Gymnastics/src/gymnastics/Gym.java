/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymnastics;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;
import java.text.*;

public class Gym {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        Scanner sf = new Scanner(new File("DataGym.in.txt"));
        NumberFormat fmt = NumberFormat.getNumberInstance();
        fmt.setMinimumFractionDigits(4); //may need to change value
        fmt.setMaximumFractionDigits(4); //may need to change value

        int maxIndx = -1; //-1 so when we increment below, the first index is 0
        String text[] = new String[1000]; //To be safe, declare more than we need
        while (sf.hasNext()) {
            maxIndx++;
            text[maxIndx] = sf.nextLine();
            //System.out.println(text[maxIndx]); //Remove rem for testing
        }

        Double[] lineAry = new Double[10];
        for (int num1 = 0; num1 <= maxIndx; num1++) {
            Scanner as = new Scanner(text[num1]);
            for (int i = 0; i < text[num1].length() - 1; i++) {
                if (as.hasNextDouble()) {
                    lineAry[i] = as.nextDouble();
                }
            }

            Arrays.sort(lineAry);

            Double[] sortAry = new Double[8];
            System.arraycopy(lineAry, 1, sortAry, 0, 8);

            double sum = 0;
            for (int i = 0; i <= sortAry.length - 1; i++) {
                sum += sortAry[i];
            }

            double avg = sum / 8;
            String avgStr = fmt.format(avg);
            System.out.println("For Competitor #" + (num1 + 1) + ", the average is " + avgStr);
        }
    }

}
