/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ascenddescend;

/**
 *
 * @author 1100015542
 */
import java.util.*;
public class AscendDescend {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String ss[] = {"Bill", "Mary", "Lee", "Agnes", "Alfred", "Thomas", "Alvin", "Bernard", "Ezra", "Herman"};
        Arrays.sort(ss); 
        System.out.println("Ascend\tDescend\n");
        int indexLength = ss.length - 1;
        for (int j = 0; j < ss.length; j++) {
            System.out.println(ss[j] + "\t" + ss[indexLength-j]);
        }
    }
    
}
