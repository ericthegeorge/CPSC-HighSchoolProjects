/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package divisiblebywhatict;

/**
 *
 * @author 1100015542
 */
public class DivisibleByWhat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

    public static boolean isDivisibleBy(int x, int d) {
        double quotient = (double) x / d;
        String quotientStr = Double.toString(quotient);
        int indx = quotientStr.indexOf('.');
        String afterDeci = quotientStr.substring(indx);
        if (afterDeci.equals(".00") || afterDeci.equals(".0")) {
            return true;
        } else {
            return false;
        }
    }

    public static int[] divisorsOf(int x) {
        String divisorsStr = "";
        for (int i = 1; i <= x; i++) {
            if (isDivisibleBy(x, i) == true) {
                divisorsStr += i + "~";
            }
        }
        String[] divisorsStrArr = divisorsStr.split("~");
        int[] divisorsArr = new int[divisorsStrArr.length];
        for (int i = 0; i < divisorsStrArr.length; i++) {
            divisorsArr[i] = Integer.parseInt(divisorsStrArr[i]);
        }
        return divisorsArr;
    }

}
