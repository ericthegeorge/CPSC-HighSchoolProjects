/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package countemright;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;

public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        boolean exit = false;
        while (exit == false) {
            System.out.print("Type in a sentence and press ENTER. ");
            Scanner sc = new Scanner(System.in);
            String userInput = ((sc.nextLine()).toUpperCase()) + "|";
            if (userInput.equals("EXIT|")) {
                exit = true;
            } else {
                String sp[];
                sp = userInput.split("S\\s*A");
                int aryLength = sp.length;
                int occurences = aryLength - 1;
                System.out.println("There are " + occurences + " occurrences. \n");
            }

        }
    }

}
