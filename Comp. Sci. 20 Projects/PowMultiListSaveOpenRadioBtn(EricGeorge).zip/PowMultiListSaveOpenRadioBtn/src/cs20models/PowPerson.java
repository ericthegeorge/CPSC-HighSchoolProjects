package cs20models;

/**
 * A class to model the problem or situation your program solves
 *
 * @author cheng
 */
public class PowPerson {

    private String name, rank, gender;
    private int serial;

    public PowPerson() {
        this.name = "";
        this.rank = "";
        this.serial = 0;
        this.gender = "";
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRank() {
        return this.rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public int getSerial() {
        return this.serial;
    }

    public void setSerial(int serial) {
        this.serial = serial;
    }

    public String getGender() {
        return this.gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String toString() {
        return this.getName();
    }

    public String getSaveString() {
        String str = this.name + " " + this.rank + " " + this.serial + " " + this.gender;
        return str;
    }
}
