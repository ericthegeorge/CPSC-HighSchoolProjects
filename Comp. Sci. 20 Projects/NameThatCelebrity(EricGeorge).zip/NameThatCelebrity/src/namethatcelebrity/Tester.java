/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package namethatcelebrity;

/**
 *
 * @author 1100015542
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String s1 = "Allan Alda";
        String s2 = "John Wayne";
        String s3 = "Gregory Peck";
        int s1Length = s1.length();
        int s2Length = s2.length();
        int s3Length = s3.length();
        System.out.println(s1 + ">>>" + s1.substring(2, s1Length - 3));
        System.out.println(s2 + ">>>" + s2.substring(2, s2Length - 3));
        System.out.println(s3 + ">>>" + s3.substring(2, s3Length - 3));
    }

}
