package gp3encdec;

/**
 *
 * @author Eric George
 */
import java.io.*;
import java.util.Scanner;
public class GP3EncDec {

    public static void main(String[] args) throws IOException { // throws IOException ?
        String plainFilePath = "Iliad_Homer.txt";
        String encryptedFilePath = "Iliad_Homer_Encrypted.txt";
        TextFile homer = new TextFile(plainFilePath);
        System.out.println(homer.fileContent);
        homer.encrypt();
        System.out.println(homer.fileContent);
        homer.decrypt();
        System.out.println(homer.fileContent);
        homer.encrypt();
        homer.saveToDisk(encryptedFilePath);

    }
}
