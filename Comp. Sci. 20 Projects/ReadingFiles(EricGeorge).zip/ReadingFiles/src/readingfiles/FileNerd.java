/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package readingfiles;

/**
 *
 * @author 1100015542
 */
import java.io.*;
import java.util.*;
public class FileNerd {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws IOException {
        Scanner fileReader = new Scanner(new File("temp_Eric\\NerdData.txt"));
        int maxIndex = -1;
        String[] theText = new String [1000];
        while (fileReader.hasNext()){ 
            maxIndex++;
            theText[maxIndex] = fileReader.nextLine();
        }
        for (int j = 0; j <= maxIndex; j++) {
            if (theText[j].startsWith("The")) {
                System.out.println(theText[j]);
            }
        }
        fileReader.close();
    }
    
}
