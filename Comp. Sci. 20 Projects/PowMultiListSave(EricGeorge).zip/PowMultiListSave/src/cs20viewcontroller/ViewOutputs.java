package cs20viewcontroller;

import cs20models.PowPerson;
import java.io.File;
import javax.swing.JFileChooser;

/**
 * Write methods in this class for displaying data in the DrawnView.
 *
 * You can use all the public instance variables you defined in AllModelsForView
 * and DrawnView as though they were part of this class! This is due to the
 * magic of subclassing (i.e. using the extends keyword).
 *
 * The methods for displaying data in the DrawnView are written as methods in
 * this class.
 *
 * Make sure to use these methods in the ViewUserActions class though, or else
 * they will be defined but never used!
 *
 * @author cheng
 */
public class ViewOutputs extends DrawnView {

    public void updatePowListDisplay() {
        powList.setListData(thePowList.toArray());
    }

    public void showPowInfo(int id) {
//        PowPerson selectedPow = powList.getSelectedValue();
        updatePowListDisplay();

        powList.setListData(thePowList.toArray());

        PowPerson aPowPerson = thePowList.getPow(id);

        if (aPowPerson != null) {
            String name = aPowPerson.getName();
            nameField.setText(name);

            String rank = aPowPerson.getRank();
            rankField.setText(rank);

            int serial = aPowPerson.getSerial();
            String serialStr = Integer.toString(serial);
            serialField.setText(serialStr);
        } else {
            nameField.setText("Person not found...");
            rankField.setText("");
        }
    }

    public void clearPowDisplay() {
        updatePowListDisplay();

        nameField.setText("");

        rankField.setText("");

        serialField.setText("");
    }

    public String showSaveDialog() {
        JFileChooser jfc = new JFileChooser();
        int status = jfc.showSaveDialog(this);
        if (status == JFileChooser.APPROVE_OPTION){
            File theFile = jfc.getSelectedFile();
            String thePath = theFile.getAbsolutePath();
            return thePath;
        }
        return null;
    }

}
