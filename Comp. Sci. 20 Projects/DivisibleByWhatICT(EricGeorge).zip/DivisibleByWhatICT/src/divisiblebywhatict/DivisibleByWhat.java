/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package divisiblebywhatict;

/**
 *
 * @author 1100015542
 */
public class DivisibleByWhat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a = 10000;
        int[] anArr = (DivisibleByWhat.divisorsOf(a));
        String aStr = "";
        for (int i = 0; i < anArr.length; i++) {
            aStr += (anArr[i]);
            if (i + 1 < anArr.length) {
                aStr += ", ";
            }
        }
//        if (aStr.equals("1, 2, 4, 5, 8, 10, 16, 20, 25, 32, 40, 50, 64, 80, 100, 125, 128, 160, 200, 250, 256, 320, 400, 500, 512, 625, 640, 800, 1000, 1250, 1280, 1600, 2000, 2500, 2560, 3125, 3200, 4000, 5000, 6250, 6400, 8000, 10000, 12500, 12800, 15625, 16000, 20000, 25000, 31250, 32000, 40000, 50000, 62500, 64000, 78125, 80000, 100000, 125000, 156250, 160000, 200000, 250000, 312500, 320000, 390625, 400000, 500000, 625000, 781250, 800000, 1000000, 1250000, 1562500, 1600000, 1953125, 2000000, 2500000, 3125000, 3906250, 4000000, 5000000, 6250000, 7812500, 8000000, 10000000, 12500000, 15625000, 20000000, 25000000, 31250000, 40000000, 50000000, 62500000, 100000000, 125000000, 200000000, 250000000, 500000000, 1000000000")){
//            System.out.println("it works");
//        }
        System.out.println(aStr);
        //System.out.println("1, 2, 4, 5, 8, 10, 16, 20, 25, 32, 40, 50, 64, 80, 100, 125, 128, 160, 200, 250, 256, 320, 400, 500, 512, 625, 640, 800, 1000, 1250, 1280, 1600, 2000, 2500, 2560, 3125, 3200, 4000, 5000, 6250, 6400, 8000, 10000, 12500, 12800, 15625, 16000, 20000, 25000, 31250, 32000, 40000, 50000, 62500, 64000, 78125, 80000, 100000, 125000, 156250, 160000, 200000, 250000, 312500, 320000, 390625, 400000, 500000, 625000, 781250, 800000, 1000000, 1250000, 1562500, 1600000, 1953125, 2000000, 2500000, 3125000, 3906250, 4000000, 5000000, 6250000, 7812500, 8000000, 10000000, 12500000, 15625000, 20000000, 25000000, 31250000, 40000000, 50000000, 62500000, 100000000, 125000000, 200000000, 250000000, 500000000, 1000000000");
        System.out.println("1, 2, 4, 5, 8, 10, 16, 20, 25, 40, 50, 80, 100, 125, 200, 250, 400, 500, 625, 1000, 1250, 2000, 2500, 5000, 10000");
    }

    public static boolean isDivisibleBy(int x, int d) {
        double quotient = (double) x / d;
        String quotientStr = Double.toString(quotient);
        int indx = quotientStr.indexOf('.');
        String afterDeci = quotientStr.substring(indx);
        if (afterDeci.equals(".00") || afterDeci.equals(".0")) {
            return true;
        } else {
            return false;
        }
    }

    public static int[] divisorsOf(int x) {
        String divisorsStr = "";
        for (int i = 1; i <= x; i++) {
            if (isDivisibleBy(x, i) == true) {
                divisorsStr += i + "~";
            }
        }
        String[] divisorsStrArr = divisorsStr.split("~");
        int[] divisorsArr = new int[divisorsStrArr.length];
        for (int i = 0; i < divisorsStrArr.length; i++) {
            divisorsArr[i] = Integer.parseInt(divisorsStrArr[i]);
        }
        return divisorsArr;
    }

}
