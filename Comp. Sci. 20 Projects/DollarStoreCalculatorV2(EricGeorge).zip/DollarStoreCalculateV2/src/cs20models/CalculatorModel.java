package cs20models;

/**
 * A class to model the problem or situation your program solves
 *
 * @author cheng
 */
public class CalculatorModel {

    private double displayedNumber = (int) 0;
    private boolean firstNumber = true;
    private boolean isDecimal = false;
    private boolean isFirstDecimal = true;
    private double resultSoFar;
    private String lastOperation;
    private boolean isPositive = true;

    //dispNum
    public double getDisplayedNumber() {
        return this.displayedNumber;
    }

    public void setDisplayedNumber(double disp) {
        this.displayedNumber = disp;

    }

    //firstNum
    public boolean getFirstNumber() {
        return this.firstNumber;
    }

    public void setFirstNumber(boolean bool) {
        this.firstNumber = bool;
    }

    //resSoFar
    public double getResultSoFar() {
        return this.resultSoFar;
    }

    public void setResultSoFar(double aNum) {
        this.resultSoFar = aNum;
    }

    //lastOp
    public String getLastOperation() {
        return this.lastOperation;
    }

    public void setLastOperation(String res) {
        this.lastOperation = res;
    }

    public boolean getIsDecimal() {
        return this.isDecimal;
    }

    public void setIsDecimal(boolean bool) {
        this.isDecimal = bool;
    }

    public boolean getIsFirstDecimal() {
        return this.isFirstDecimal;
    }

    public void setIsFirstDecimal(boolean bool) {
        this.isFirstDecimal = bool;
    }

    public boolean getIsPositive() {
        return this.isPositive;
    }

    public void setIsPositive(boolean bool) {
        this.isPositive = bool;
    }

}
