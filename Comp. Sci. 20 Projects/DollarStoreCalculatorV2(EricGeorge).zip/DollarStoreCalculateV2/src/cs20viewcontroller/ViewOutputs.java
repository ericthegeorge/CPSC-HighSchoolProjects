package cs20viewcontroller;

import java.text.NumberFormat;

/**
 * Write methods in this class for displaying data in the DrawnView.
 *
 * You can use all the public instance variables you defined in AllModelsForView
 * and DrawnView as though they were part of this class! This is due to the
 * magic of subclassing (i.e. using the extends keyword).
 *
 * The methods for displaying data in the DrawnView are written as methods in
 * this class.
 *
 * Make sure to use these methods in the ViewUserActions class though, or else
 * they will be defined but never used!
 *
 * @author cheng
 */
public class ViewOutputs extends DrawnView {

//    public void updateThoughtDisplayed() {
////        outputTextField.setText(this.aDeepThoughtModel.getThought());
//    }
    public void updateDisplay() {
        String dispStr = Double.toString(aCalculatorModel.getDisplayedNumber());
        displayTextLabel.setText(dispStr);
    }

    public void clearDisplay() {
        aCalculatorModel.setDisplayedNumber(0);
        updateDisplay();
    }

    public void doMath(double anInput, String anOp) {
        //doMath on num button not ops
        //sadly impossible
        if (aCalculatorModel.getFirstNumber() == true) {
            aCalculatorModel.setResultSoFar(anInput);
            aCalculatorModel.setLastOperation(anOp);
            aCalculatorModel.setFirstNumber(false);
        } else {
            if (anOp.equals("/")) {
                double num1 = aCalculatorModel.getResultSoFar();
                double result = num1 / anInput;
                NumberFormat nf = NumberFormat.getNumberInstance();
                nf.setMaximumFractionDigits(2);
                nf.setMinimumFractionDigits(2);
                result = Double.parseDouble(nf.format(result));
                aCalculatorModel.setResultSoFar(result);
            }
            if (anOp.equals("x")) {
                double factor = aCalculatorModel.getResultSoFar();
                double result = factor * anInput;
                NumberFormat nf = NumberFormat.getNumberInstance();
                nf.setMaximumFractionDigits(2);
                nf.setMinimumFractionDigits(2);
                result = Double.parseDouble(nf.format(result));
                aCalculatorModel.setResultSoFar(result);
            }
            if (anOp.equals("-")) {
                double num1 = aCalculatorModel.getResultSoFar();
                double result = num1 - anInput;
                NumberFormat nf = NumberFormat.getNumberInstance();
                nf.setMaximumFractionDigits(2);
                nf.setMinimumFractionDigits(2);
                result = Double.parseDouble(nf.format(result));
                aCalculatorModel.setResultSoFar(result);
            }
            if (anOp.equals("+")) {
                double factor = aCalculatorModel.getResultSoFar();
                double result = factor + anInput;
                NumberFormat nf = NumberFormat.getNumberInstance();
                nf.setMaximumFractionDigits(2);
                nf.setMinimumFractionDigits(2);
                result = Double.parseDouble(nf.format(result));
                aCalculatorModel.setResultSoFar(result);
            }
            if (aCalculatorModel.getResultSoFar() < 0) {
                aCalculatorModel.setIsPositive(false);
            }
            if (aCalculatorModel.getResultSoFar() >= 0) {
                aCalculatorModel.setIsPositive(true);
            }
        }

    }
    
    public void clearAll () {
        aCalculatorModel.setDisplayedNumber(0);
        aCalculatorModel.setResultSoFar(0);
        aCalculatorModel.setFirstNumber(true);
        aCalculatorModel.setLastOperation("");
        aCalculatorModel.setIsDecimal(false);
        aCalculatorModel.setIsFirstDecimal(false);
        updateDisplay();
    }
}
