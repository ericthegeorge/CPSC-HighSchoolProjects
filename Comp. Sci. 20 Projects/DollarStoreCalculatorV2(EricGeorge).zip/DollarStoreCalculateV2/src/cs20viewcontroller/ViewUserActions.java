/*
 * The controller classes (like the ViewUserActions class) provides actions
 * that the user can trigger through the view classes.  Those actions are 
 * written in this class as private inner classes (i.e. classes 
 * declared inside another class).
 *
 * You can use all the public instance variables you defined in AllModelsForView, 
 * DrawnView, and ViewOutputs as though they were part of this class! This is 
 * due to the magic of subclassing (i.e. using the extends keyword).
 */
package cs20viewcontroller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * ViewUserActions is a class that contains actions users can trigger.
 *
 * User actions are written as private inner classes that implements the
 * ActionListener interface. These actions must be "wired" into the DrawnView in
 * the ViewUserActions constructor, or else they won't be triggered by the user.
 *
 * Actions that the user can trigger are meant to manipulate some model classes
 * by sending messages to them to tell them to update their data members.
 *
 * Actions that the user can trigger can also be used to manipulate the GUI by
 * sending messages to the view classes (e.g. the DrawnView class) to tell them
 * to update themselves (e.g. to redraw themselves on the screen).
 *
 * @author cheng
 */
public class ViewUserActions extends ViewOutputs {

    /*
     * Step 1 of 2 for writing user actions.
     * -------------------------------------
     *
     * User actions are written as private inner classes that implement
     * ActionListener, and override the actionPerformed method.
     *
     * Use the following as a template for writting more user actions.
     */
//    private class CopyUserText implements ActionListener {
//
//        @Override
//        public void actionPerformed(ActionEvent ae) {
//            String userText = userTextField.getText(); // get text from view
//            aDeepThoughtModel.setThought(userText); // update model
//            updateThoughtDisplayed(); // tell view to update
//              displayTextLabel.setText("hi");
//        }
//    }
    private class ZeroButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double disp = aCalculatorModel.getDisplayedNumber();

            String dispStr = Double.toString(disp);
            String dispStrRep = dispStr.replace('.', ' ');

            int spaceIndx = dispStrRep.indexOf(' ');
            String dispStrRep1 = dispStrRep.substring(0, spaceIndx);
            String dispStrRep2 = dispStrRep.substring(spaceIndx + 1);

            int beforeDeci = Integer.parseInt(dispStrRep1);
            int afterDeci = Integer.parseInt(dispStrRep2);

            if (aCalculatorModel.getIsDecimal() == true) {
                if (aCalculatorModel.getIsFirstDecimal() == true) {
                    String afterDeciStr = "" + 0;
                    String firstDeciRtnStr = beforeDeci + "." + afterDeciStr;
                    double firstDeciRtn = Double.parseDouble(firstDeciRtnStr);
                    aCalculatorModel.setDisplayedNumber(firstDeciRtn);
                    aCalculatorModel.setIsFirstDecimal(false);
                } else {
                    double dispStrFin = Double.parseDouble(dispStr + 0);
                    aCalculatorModel.setDisplayedNumber(dispStrFin);
                }
            } else {
                String noDeciPlusStr = beforeDeci + "0";
                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
                aCalculatorModel.setDisplayedNumber(noDeciPlus);
            }

//            if (afterDeci == 0) {
//                String noDeciPlusStr = beforeDeci + "0";
//                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
//                aCalculatorModel.setDisplayedNumber(noDeciPlus);
//            } else {
//                double dispStrFin = Double.parseDouble(dispStr + 0);
//                aCalculatorModel.setDisplayedNumber(dispStrFin);
//            }
            updateDisplay();
        }
    }

    private class OneButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double disp = aCalculatorModel.getDisplayedNumber();

            String dispStr = Double.toString(disp);
            String dispStrRep = dispStr.replace('.', ' ');

            int spaceIndx = dispStrRep.indexOf(' ');
            String dispStrRep1 = dispStrRep.substring(0, spaceIndx);
            String dispStrRep2 = dispStrRep.substring(spaceIndx + 1);

            int beforeDeci = Integer.parseInt(dispStrRep1);
            int afterDeci = Integer.parseInt(dispStrRep2);

            if (aCalculatorModel.getIsDecimal() == true) {
                if (aCalculatorModel.getIsFirstDecimal() == true) {
                    String afterDeciStr = "" + 1;
                    String firstDeciRtnStr = beforeDeci + "." + afterDeciStr;
                    double firstDeciRtn = Double.parseDouble(firstDeciRtnStr);
                    aCalculatorModel.setDisplayedNumber(firstDeciRtn);
                    aCalculatorModel.setIsFirstDecimal(false);
                } else {
                    double dispStrFin = Double.parseDouble(dispStr + 1);
                    aCalculatorModel.setDisplayedNumber(dispStrFin);
                }
            } else {
                String noDeciPlusStr = beforeDeci + "1";
                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
                aCalculatorModel.setDisplayedNumber(noDeciPlus);
            }

//            if (afterDeci == 0) {
//                String noDeciPlusStr = beforeDeci + "1";
//                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
//                aCalculatorModel.setDisplayedNumber(noDeciPlus);
//            } else {
//                double dispStrFin = Double.parseDouble(dispStr + 1);
//                aCalculatorModel.setDisplayedNumber(dispStrFin);
//            }
            updateDisplay();
        }
    }

    private class TwoButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double disp = aCalculatorModel.getDisplayedNumber();

            String dispStr = Double.toString(disp);
            String dispStrRep = dispStr.replace('.', ' ');

            int spaceIndx = dispStrRep.indexOf(' ');
            String dispStrRep1 = dispStrRep.substring(0, spaceIndx);
            String dispStrRep2 = dispStrRep.substring(spaceIndx + 1);

            int beforeDeci = Integer.parseInt(dispStrRep1);
            int afterDeci = Integer.parseInt(dispStrRep2);

            if (aCalculatorModel.getIsDecimal() == true) {
                if (aCalculatorModel.getIsFirstDecimal() == true) {
                    String afterDeciStr = "" + 2;
                    String firstDeciRtnStr = beforeDeci + "." + afterDeciStr;
                    double firstDeciRtn = Double.parseDouble(firstDeciRtnStr);
                    aCalculatorModel.setDisplayedNumber(firstDeciRtn);
                    aCalculatorModel.setIsFirstDecimal(false);
                } else {
                    double dispStrFin = Double.parseDouble(dispStr + 2);
                    aCalculatorModel.setDisplayedNumber(dispStrFin);
                }
            } else {
                String noDeciPlusStr = beforeDeci + "2";
                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
                aCalculatorModel.setDisplayedNumber(noDeciPlus);
            }

//            if (afterDeci == 0) {
//                String noDeciPlusStr = beforeDeci + "2";
//                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
//                aCalculatorModel.setDisplayedNumber(noDeciPlus);
//            } else {
//                double dispStrFin = Double.parseDouble(dispStr + 2);
//                aCalculatorModel.setDisplayedNumber(dispStrFin);
//            }
            updateDisplay();
        }
    }

    private class ThreeButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double disp = aCalculatorModel.getDisplayedNumber();

            String dispStr = Double.toString(disp);
            String dispStrRep = dispStr.replace('.', ' ');

            int spaceIndx = dispStrRep.indexOf(' ');
            String dispStrRep1 = dispStrRep.substring(0, spaceIndx);
            String dispStrRep2 = dispStrRep.substring(spaceIndx + 1);

            int beforeDeci = Integer.parseInt(dispStrRep1);
            int afterDeci = Integer.parseInt(dispStrRep2);

            if (aCalculatorModel.getIsDecimal() == true) {
                if (aCalculatorModel.getIsFirstDecimal() == true) {
                    String afterDeciStr = "" + 3;
                    String firstDeciRtnStr = beforeDeci + "." + afterDeciStr;
                    double firstDeciRtn = Double.parseDouble(firstDeciRtnStr);
                    aCalculatorModel.setDisplayedNumber(firstDeciRtn);
                    aCalculatorModel.setIsFirstDecimal(false);
                } else {
                    double dispStrFin = Double.parseDouble(dispStr + 3);
                    aCalculatorModel.setDisplayedNumber(dispStrFin);
                }
            } else {
                String noDeciPlusStr = beforeDeci + "3";
                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
                aCalculatorModel.setDisplayedNumber(noDeciPlus);
            }

//            if (afterDeci == 0) {
//                String noDeciPlusStr = beforeDeci + "3";
//                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
//                aCalculatorModel.setDisplayedNumber(noDeciPlus);
//            } else {
//                double dispStrFin = Double.parseDouble(dispStr + 3);
//                aCalculatorModel.setDisplayedNumber(dispStrFin);
//            }
            updateDisplay();
        }
    }

    private class FourButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double disp = aCalculatorModel.getDisplayedNumber();

            String dispStr = Double.toString(disp);
            String dispStrRep = dispStr.replace('.', ' ');

            int spaceIndx = dispStrRep.indexOf(' ');
            String dispStrRep1 = dispStrRep.substring(0, spaceIndx);
            String dispStrRep2 = dispStrRep.substring(spaceIndx + 1);

            int beforeDeci = Integer.parseInt(dispStrRep1);
            int afterDeci = Integer.parseInt(dispStrRep2);

            if (aCalculatorModel.getIsDecimal() == true) {
                if (aCalculatorModel.getIsFirstDecimal() == true) {
                    String afterDeciStr = "" + 4;
                    String firstDeciRtnStr = beforeDeci + "." + afterDeciStr;
                    double firstDeciRtn = Double.parseDouble(firstDeciRtnStr);
                    aCalculatorModel.setDisplayedNumber(firstDeciRtn);
                    aCalculatorModel.setIsFirstDecimal(false);
                } else {
                    double dispStrFin = Double.parseDouble(dispStr + 4);
                    aCalculatorModel.setDisplayedNumber(dispStrFin);
                }
            } else {
                String noDeciPlusStr = beforeDeci + "4";
                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
                aCalculatorModel.setDisplayedNumber(noDeciPlus);
            }

//            if (afterDeci == 0) {
//                String noDeciPlusStr = beforeDeci + "4";
//                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
//                aCalculatorModel.setDisplayedNumber(noDeciPlus);
//            } else {
//                double dispStrFin = Double.parseDouble(dispStr + 4);
//                aCalculatorModel.setDisplayedNumber(dispStrFin);
//            }
            updateDisplay();
        }
    }

    private class FiveButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double disp = aCalculatorModel.getDisplayedNumber();

            String dispStr = Double.toString(disp);
            String dispStrRep = dispStr.replace('.', ' ');

            int spaceIndx = dispStrRep.indexOf(' ');
            String dispStrRep1 = dispStrRep.substring(0, spaceIndx);
            String dispStrRep2 = dispStrRep.substring(spaceIndx + 1);

            int beforeDeci = Integer.parseInt(dispStrRep1);
            int afterDeci = Integer.parseInt(dispStrRep2);

            if (aCalculatorModel.getIsDecimal() == true) {
                if (aCalculatorModel.getIsFirstDecimal() == true) {
                    String afterDeciStr = "" + 5;
                    String firstDeciRtnStr = beforeDeci + "." + afterDeciStr;
                    double firstDeciRtn = Double.parseDouble(firstDeciRtnStr);
                    aCalculatorModel.setDisplayedNumber(firstDeciRtn);
                    aCalculatorModel.setIsFirstDecimal(false);
                } else {
                    double dispStrFin = Double.parseDouble(dispStr + 5);
                    aCalculatorModel.setDisplayedNumber(dispStrFin);
                }
            } else {
                String noDeciPlusStr = beforeDeci + "5";
                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
                aCalculatorModel.setDisplayedNumber(noDeciPlus);
            }

//            if (afterDeci == 0) {
//                String noDeciPlusStr = beforeDeci + "5";
//                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
//                aCalculatorModel.setDisplayedNumber(noDeciPlus);
//            } else {
//                double dispStrFin = Double.parseDouble(dispStr + 5);
//                aCalculatorModel.setDisplayedNumber(dispStrFin);
//            }
            updateDisplay();
        }
    }

    private class SixButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double disp = aCalculatorModel.getDisplayedNumber();

            String dispStr = Double.toString(disp);
            String dispStrRep = dispStr.replace('.', ' ');

            int spaceIndx = dispStrRep.indexOf(' ');
            String dispStrRep1 = dispStrRep.substring(0, spaceIndx);
            String dispStrRep2 = dispStrRep.substring(spaceIndx + 1);

            int beforeDeci = Integer.parseInt(dispStrRep1);
            int afterDeci = Integer.parseInt(dispStrRep2);

            if (aCalculatorModel.getIsDecimal() == true) {
                if (aCalculatorModel.getIsFirstDecimal() == true) {
                    String afterDeciStr = "" + 6;
                    String firstDeciRtnStr = beforeDeci + "." + afterDeciStr;
                    double firstDeciRtn = Double.parseDouble(firstDeciRtnStr);
                    aCalculatorModel.setDisplayedNumber(firstDeciRtn);
                    aCalculatorModel.setIsFirstDecimal(false);
                } else {
                    double dispStrFin = Double.parseDouble(dispStr + 6);
                    aCalculatorModel.setDisplayedNumber(dispStrFin);
                }
            } else {
                String noDeciPlusStr = beforeDeci + "6";
                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
                aCalculatorModel.setDisplayedNumber(noDeciPlus);
            }

//            if (afterDeci == 0) {
//                String noDeciPlusStr = beforeDeci + "6";
//                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
//                aCalculatorModel.setDisplayedNumber(noDeciPlus);
//            } else {
//                double dispStrFin = Double.parseDouble(dispStr + 6);
//                aCalculatorModel.setDisplayedNumber(dispStrFin);
//            }
            updateDisplay();
        }
    }

    private class SevenButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double disp = aCalculatorModel.getDisplayedNumber();

            String dispStr = Double.toString(disp);
            String dispStrRep = dispStr.replace('.', ' ');

            int spaceIndx = dispStrRep.indexOf(' ');
            String dispStrRep1 = dispStrRep.substring(0, spaceIndx);
            String dispStrRep2 = dispStrRep.substring(spaceIndx + 1);

            int beforeDeci = Integer.parseInt(dispStrRep1);
            int afterDeci = Integer.parseInt(dispStrRep2);

            if (aCalculatorModel.getIsDecimal() == true) {
                if (aCalculatorModel.getIsFirstDecimal() == true) {
                    String afterDeciStr = "" + 7;
                    String firstDeciRtnStr = beforeDeci + "." + afterDeciStr;
                    double firstDeciRtn = Double.parseDouble(firstDeciRtnStr);
                    aCalculatorModel.setDisplayedNumber(firstDeciRtn);
                    aCalculatorModel.setIsFirstDecimal(false);
                } else {
                    double dispStrFin = Double.parseDouble(dispStr + 7);
                    aCalculatorModel.setDisplayedNumber(dispStrFin);
                }
            } else {
                String noDeciPlusStr = beforeDeci + "7";
                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
                aCalculatorModel.setDisplayedNumber(noDeciPlus);
            }

//            if (afterDeci == 0) {
//                String noDeciPlusStr = beforeDeci + "7";
//                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
//                aCalculatorModel.setDisplayedNumber(noDeciPlus);
//            } else {
//                double dispStrFin = Double.parseDouble(dispStr + 7);
//                aCalculatorModel.setDisplayedNumber(dispStrFin);
//            }
            updateDisplay();
        }
    }

    private class EightButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double disp = aCalculatorModel.getDisplayedNumber();

            String dispStr = Double.toString(disp);
            String dispStrRep = dispStr.replace('.', ' ');

            int spaceIndx = dispStrRep.indexOf(' ');
            String dispStrRep1 = dispStrRep.substring(0, spaceIndx);
            String dispStrRep2 = dispStrRep.substring(spaceIndx + 1);

            int beforeDeci = Integer.parseInt(dispStrRep1);
            int afterDeci = Integer.parseInt(dispStrRep2);

            if (aCalculatorModel.getIsDecimal() == true) {
                if (aCalculatorModel.getIsFirstDecimal() == true) {
                    String afterDeciStr = "" + 8;
                    String firstDeciRtnStr = beforeDeci + "." + afterDeciStr;

                    double firstDeciRtn = Double.parseDouble(firstDeciRtnStr);

                    aCalculatorModel.setDisplayedNumber(firstDeciRtn);
                    aCalculatorModel.setIsFirstDecimal(false);
                } else {
                    double dispStrFin = Double.parseDouble(dispStr + 8);
                    aCalculatorModel.setDisplayedNumber(dispStrFin);
                }
            } else {
                String noDeciPlusStr = beforeDeci + "8";
                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
                aCalculatorModel.setDisplayedNumber(noDeciPlus);
            }

//            if (afterDeci == 0) {
//                String noDeciPlusStr = beforeDeci + "8";
//                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
//                aCalculatorModel.setDisplayedNumber(noDeciPlus);
//            } else {
//                double dispStrFin = Double.parseDouble(dispStr + 8);
//                aCalculatorModel.setDisplayedNumber(dispStrFin);
//            }
            updateDisplay();
        }
    }

    private class NineButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double disp = aCalculatorModel.getDisplayedNumber();

            String dispStr = Double.toString(disp);
            String dispStrRep = dispStr.replace('.', ' ');

            int spaceIndx = dispStrRep.indexOf(' ');
            String dispStrRep1 = dispStrRep.substring(0, spaceIndx);
            String dispStrRep2 = dispStrRep.substring(spaceIndx + 1);

            int beforeDeci = Integer.parseInt(dispStrRep1);
            int afterDeci = Integer.parseInt(dispStrRep2);

            if (aCalculatorModel.getIsDecimal() == true) {
                if (aCalculatorModel.getIsFirstDecimal() == true) {
                    String afterDeciStr = "" + 9;
                    String firstDeciRtnStr = beforeDeci + "." + afterDeciStr;
                    double firstDeciRtn = Double.parseDouble(firstDeciRtnStr);
                    aCalculatorModel.setDisplayedNumber(firstDeciRtn);
                    aCalculatorModel.setIsFirstDecimal(false);
                } else {
                    double dispStrFin = Double.parseDouble(dispStr + 9);
                    aCalculatorModel.setDisplayedNumber(dispStrFin);
                }
            } else {
                String noDeciPlusStr = beforeDeci + "9";
                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
                aCalculatorModel.setDisplayedNumber(noDeciPlus);
            }

//            if (afterDeci == 0) {
//                String noDeciPlusStr = beforeDeci + "9";
//                double noDeciPlus = Double.parseDouble(noDeciPlusStr);
//                aCalculatorModel.setDisplayedNumber(noDeciPlus);
//            } else {
//                double dispStrFin = Double.parseDouble(dispStr + 9);
//                aCalculatorModel.setDisplayedNumber(dispStrFin);
//            }
            updateDisplay();
        }
    }

    private class PlusButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double dispNum = aCalculatorModel.getDisplayedNumber();
            doMath(dispNum, aCalculatorModel.getLastOperation());
            aCalculatorModel.setLastOperation("+");
            clearDisplay();
            aCalculatorModel.setIsDecimal(false);
        }
    }

    private class MinusButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double dispNum = aCalculatorModel.getDisplayedNumber();
            doMath(dispNum, aCalculatorModel.getLastOperation());
            aCalculatorModel.setLastOperation("-");
            clearDisplay();
            aCalculatorModel.setIsDecimal(false);
        }
    }

    private class DivideButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double dispNum = aCalculatorModel.getDisplayedNumber();
            doMath(dispNum, aCalculatorModel.getLastOperation());
            aCalculatorModel.setLastOperation("/");
            clearDisplay();
            aCalculatorModel.setIsDecimal(false);
        }
    }

    private class MultiplyButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double dispNum = aCalculatorModel.getDisplayedNumber();
            doMath(dispNum, aCalculatorModel.getLastOperation());
            aCalculatorModel.setLastOperation("x");
            clearDisplay();
            aCalculatorModel.setIsDecimal(false);
        }
    }

    private class EqualButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double dispNum = aCalculatorModel.getDisplayedNumber();
            doMath(dispNum, aCalculatorModel.getLastOperation());
            aCalculatorModel.setLastOperation("=");
            aCalculatorModel.setFirstNumber(true);
            aCalculatorModel.setDisplayedNumber(aCalculatorModel.getResultSoFar());
            updateDisplay();
            aCalculatorModel.setIsDecimal(false);
        }
    }

    private class ClearButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            clearAll();
        }
    }

    private class DecimalButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            aCalculatorModel.setIsDecimal(true);
            aCalculatorModel.setIsFirstDecimal(true);
        }
    }

    private class SignButtonAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (aCalculatorModel.getIsPositive() == true) {
                Double disp = aCalculatorModel.getDisplayedNumber();
                String dispStr = Double.toString(disp);
                String dispStrA = "-" + dispStr;
                double dispA = Double.parseDouble(dispStrA);
                aCalculatorModel.setDisplayedNumber(dispA);
                aCalculatorModel.setIsPositive(false);
                updateDisplay();
            } else  if (aCalculatorModel.getIsPositive() == false){
                Double disp = aCalculatorModel.getDisplayedNumber();
                String dispStr = Double.toString(disp);
                String dispStrA = dispStr.replace("-", "");
                double dispA = Double.parseDouble(dispStrA);
                aCalculatorModel.setDisplayedNumber(dispA);
                aCalculatorModel.setIsPositive(true);
                updateDisplay();
            }
        }
    }

    /*
     * ViewUserActions constructor used for wiring user actions to GUI elements
     */
    public ViewUserActions() {
        /*
         * Step 2 of 2 for writing user actions.
         * -------------------------------------
         *
         * Once a private inner class has been written for a user action, you
         * can wire it to a GUI element (i.e. one of GUI elements you drew in
         * the DrawnView class and which you gave a memorable public variable
         * name!).
         *
         * Use the following as a template for wiring more user actions.
         */
//        aButton.addActionListener(new CopyUserText());
        zeroButton.addActionListener(new ZeroButtonAction());
        oneButton.addActionListener(new OneButtonAction());
        twoButton.addActionListener(new TwoButtonAction());
        threeButton.addActionListener(new ThreeButtonAction());
        fourButton.addActionListener(new FourButtonAction());
        fiveButton.addActionListener(new FiveButtonAction());
        sixButton.addActionListener(new SixButtonAction());
        sevenButton.addActionListener(new SevenButtonAction());
        eightButton.addActionListener(new EightButtonAction());
        nineButton.addActionListener(new NineButtonAction());
        plusButton.addActionListener(new PlusButtonAction());
        minusButton.addActionListener(new MinusButtonAction());
        divideButton.addActionListener(new DivideButtonAction());
        multiplyButton.addActionListener(new MultiplyButtonAction());
        equalButton.addActionListener(new EqualButtonAction());
        clearButton.addActionListener(new ClearButtonAction());
        decimalButton.addActionListener(new DecimalButtonAction());
        signButton.addActionListener(new SignButtonAction());
    }
}
